"""
调度任务Repository - 实现 ISchedulerRepository 接口

使用 SQLAlchemy ORM 操作 quant.scheduler_tasks 和 quant.scheduler_runs 表。
"""
import json
import logging
from datetime import datetime, timezone, timedelta
from typing import Dict, List, Optional, Any

from sqlalchemy import Float, String, and_, case, column, func, or_, select, table
from sqlalchemy.dialects.postgresql import insert as pg_insert


# APScheduler 自己的 jobstore 表（public.apscheduler_jobs）。**刻意不建 ORM 模型**：
#   · 建表/迁移归 APScheduler（SQLAlchemyJobStore.start() 自己 CREATE TABLE IF NOT EXISTS），
#     本仓只读它的一行状态 —— 映射进 Base 等于给同一张表造第二个 owner；
#   · 本仓 scripts/migrate_*.py 会调 Base.metadata.create_all(engine)，一旦加入模型，
#     这些脚本就会按我们的猜测去 CREATE 一张第三方表（schema 漂移风险外溢）；
#   · APScheduler 大版本升级会改 jobstore 的 DDL（3.x 为 id varchar(191) /
#     next_run_time double precision / job_state bytea），冻结成模型后漂移只在运行期暴露；
#   · 本表只有一条只读探测语句，且调用方已有 except 兜底（失败退回严格检查）。
# 因此用 Core 的轻量 table()/column() 表达：不进 Base.metadata（无 create_all 副作用）、
# 无 ORM 身份/脏检查语义，SQL 由 Core 生成（非字符串拼接），取值仍走绑定参数。
_APSCHEDULER_JOBS = table(
    'apscheduler_jobs',
    column('id', String(191)),
    column('next_run_time', Float),
    schema='public',
)

from domain.ports import ISchedulerRepository
from infrastructure.persistence.orm import get_session
from infrastructure.persistence.orm.models.scheduler import (
    SchedulerTaskConfig,
    SchedulerRun,
)
from infrastructure.scheduler.scheduler import next_run_time as _calc_next_run_time, parse_cron
from infrastructure.scheduler.task_fields import validate_domain

logger = logging.getLogger(__name__)


def _json_safe(value: Any) -> Any:
    """把 handler 返回值转成 JSONB 可写形态（date/datetime/Decimal/dataclass → 可序列化）。

    失败时退回 str(value)，绝不因为"记录写不进去"把成功任务记成失败。
    """
    if value is None:
        return None
    try:
        from adapters.shared.json_helpers import sanitize_for_json
        return sanitize_for_json(value)
    except Exception:
        try:
            import json as _json
            _json.dumps(value, ensure_ascii=False)
            return value
        except (TypeError, ValueError):
            return str(value)



def _normalize_params(raw: Any) -> Dict[str, Any]:
    """把 params 归一化成 dict —— 它可能是 dict，也可能是 **JSON 字符串**。

    2026-09-13（w-a9ec14d7）：软删除那条任务的 params 存的是字符串，
    直接 dict(raw) 会抛 "dictionary update sequence element #0 has length 1; 2 is required"。
    数据形态有几种就要处理几种，否则同一条路径会在某些行上炸、在另一些行上正常 —— 最难查的那类 bug。
    """
    if raw is None:
        return {}
    if isinstance(raw, dict):
        return dict(raw)
    if isinstance(raw, str):
        try:
            v = json.loads(raw)
        except (json.JSONDecodeError, TypeError):
            return {}
        return dict(v) if isinstance(v, dict) else {}
    return {}

class SchedulerRepository(ISchedulerRepository):
    """调度任务仓储 - SQLAlchemy ORM 实现"""

    def __init__(self, session=None):
        self._session = session

    @property
    def session(self):
        return self._session or get_session()

    def _safe_rollback(self):
        try:
            self.session.rollback()
        except Exception as e:
            logger.warning(f"rollback failed: {e}")

    def _row_to_dict(self, row) -> Optional[Dict[str, Any]]:
        if row is None:
            return None
        return {c.key: getattr(row, c.key) for c in row.__table__.columns}

    # ── Task CRUD ──

    @staticmethod
    def _is_soft_deleted(config) -> bool:
        """软删除判定：DELETE 路由写 params._deleted_at；个别旧路径可能写 deleted_at 列。

        两处都要看：只看一处在数据形态变化时会静默漏判，于是又回到「名字被隐形占用」。
        """
        if getattr(config, 'deleted_at', None):
            return True
        return bool(_normalize_params(getattr(config, 'params', None)).get('_deleted_at'))

    def add_task(
        self,
        name: str,
        cron_expression: str,
        command: str,
        params: Optional[Dict[str, Any]] = None,
        description: Optional[str] = None,
        task_type: str = 'cron',
        domain: Optional[str] = None,
    ) -> int:
        # 验证 task_type
        valid_types = ['cron', 'delay', 'interval', 'once']
        if task_type not in valid_types:
            raise ValueError(f"Invalid task_type {task_type!r}, must be one of {valid_types}")

        # 六域打标（2026-09-13, REQ-c970e5）：创建路径此前完全不接该字段 → 新任务必然 NULL。
        # 非法值在写入前拒绝；不传 / 空串 = 未打标（保持 NULL，交给对账暴露，不设默认值）。
        domain = validate_domain(domain)

        # 只有 cron 类型需要验证 cron 表达式；Agent OS 托管伪任务（cron 保留字
        # managed_by_agent_*）不是真实 cron，跳过校验与 next_run 计算
        # （2026-09-01 修复：webhook 新任务名写库曾因 parse_cron 抛异常被吞）。
        _is_agent_os_placeholder = str(cron_expression).startswith("managed_by_agent_")
        if task_type == 'cron' and not _is_agent_os_placeholder:
            parse_cron(cron_expression)

        existing = self.session.query(SchedulerTaskConfig).filter_by(name=name).first()
        if existing is not None:
            # 2026-09-13（w-a9ec14d7）：DELETE 路由只做**软删除**（params._deleted_at + is_enabled=False），
            # 名称却仍被占用 —— 于是"删掉再建同名"会报 already exists，而那条被删的任务在列表里
            # 又看不见（_list_visible_tasks 会过滤软删除）→ 用户面对的是一个**隐形的名字占用**。
            # 处理：同名任务若已被软删除，则**复活该行**（复用 id，避免出现同名两行）而不是报错。
            if not self._is_soft_deleted(existing):
                raise ValueError(f"Task name {name!r} already exists")
            _next = None
            if task_type == 'cron' and not _is_agent_os_placeholder:
                _next = _calc_next_run_time(cron_expression)
            # params 可能是 dict，也可能是 **JSON 字符串**（实测：软删除那条就是字符串，
            # dict(str) 会抛 "dictionary update sequence element #0 has length 1; 2 is required"）。
            _params = _normalize_params(existing.params)
            _params.pop('_deleted_at', None)
            existing.description = description
            existing.cron_expression = cron_expression
            existing.command = command
            existing.params = _params
            existing.is_enabled = True
            existing.task_type = task_type
            existing.next_run_at = _next
            if domain is not None:
                # 复活时若显式给了 domain 就一并打标；不给则保留原值（不猜、不覆盖）
                existing.domain = domain
            try:
                self.session.commit()
                self.session.refresh(existing)
                logger.info("Task %r revived (id=%s, was soft-deleted) instead of raising already-exists",
                            name, existing.id)
                return existing.id
            except Exception:
                self.session.rollback()
                raise

        # 延迟任务和一次性任务不需要计算 next_run（由 APScheduler 管理）
        next_run = None
        if task_type == 'cron' and not _is_agent_os_placeholder:
            next_run = _calc_next_run_time(cron_expression)

        config = SchedulerTaskConfig(
            name=name,
            description=description,
            cron_expression=cron_expression,
            command=command,
            params=params or {},
            is_enabled=True,
            task_type=task_type,
            next_run_at=next_run,
            domain=domain,
        )
        try:
            self.session.add(config)
            self.session.commit()
            self.session.refresh(config)
            logger.info("Task %r added (id=%s, type=%s)", name, config.id, task_type)
            return config.id
        except Exception:
            self.session.rollback()
            raise

    def remove_task(self, task_id: int) -> bool:
        try:
            config = self.session.get(SchedulerTaskConfig, task_id)
            if config is None:
                return False
            self.session.delete(config)
            self.session.commit()
            logger.info("Task id=%s removed", task_id)
            return True
        except Exception:
            self.session.rollback()
            raise

    def update_task(self, task_id: int, **kwargs) -> bool:
        allowed = {"name", "description", "cron_expression", "command", "params", "is_enabled", "task_type", "domain"}
        updates = {k: v for k, v in kwargs.items() if k in allowed}
        if not updates:
            return False

        # 验证 task_type
        if "task_type" in updates:
            valid_types = ['cron', 'delay', 'interval', 'once']
            if updates["task_type"] not in valid_types:
                raise ValueError(f"Invalid task_type {updates['task_type']!r}, must be one of {valid_types}")

        # 六域打标（2026-09-13, REQ-c970e5）：更新路径同样支持改标（补标/纠错）
        if "domain" in updates:
            updates["domain"] = validate_domain(updates["domain"])

        # 获取当前任务配置
        task = self.get_task(task_id)
        if task is None:
            return False

        # 确定最终的 task_type
        final_task_type = updates.get("task_type", task.get("task_type", "cron"))

        # 只有 cron 类型需要更新 next_run_at
        if "cron_expression" in updates and final_task_type == "cron":
            updates["next_run_at"] = _calc_next_run_time(updates["cron_expression"])
        elif updates.get("is_enabled") is True and final_task_type == "cron":
            updates["next_run_at"] = _calc_next_run_time(task["cron_expression"])

        if "params" in updates and isinstance(updates["params"], dict):
            updates["params"] = json.dumps(updates["params"])

        try:
            config = self.session.get(SchedulerTaskConfig, task_id)
            if config is None:
                return False
            for key, value in updates.items():
                setattr(config, key, value)
            self.session.commit()
            return True
        except Exception:
            self.session.rollback()
            raise

    def get_task(self, task_id: int) -> Optional[Dict[str, Any]]:
        try:
            config = self.session.get(SchedulerTaskConfig, task_id)
            return self._row_to_dict(config)
        except Exception as e:  # noqa: BLE001
            self._safe_rollback()
            # 2026-10-02（REQ-261001145152-3982 审查）：**失败必须可见**。
            # 原先这里 `except Exception: … return None/0` 是**静默**的 —— 而调用方会把它
            # 读成业务事实，且这两种解释的后果完全不同：
            #   · `apscheduler_service` 用它算 `expected`（启用任务数）→ 读失败得 0，
            #     会被当成"没有任务要调度"（该服务里本就有
            #     `reconcile_refuses_empty_desired_set` 这类护栏，说明该失败模式是已知的）；
            #   · `scheduler_config_service` 用它判断"任务是否存在"→ 读失败得 None，
            #     会被当成"不存在"而**重复创建**。
            # 与同文件 `list_tasks` 的既有做法对齐：**记 error 再返回**（返回值不变，
            # 不改调用方语义，只是不再让失败无声无息）。
            logger.error(f"get_task 读取失败（返回 None，调用方无法与'任务不存在'区分）: task_id={task_id}: {e}", exc_info=True)
            return None

    def get_task_by_name(self, name: str) -> Optional[Dict[str, Any]]:
        try:
            config = self.session.query(SchedulerTaskConfig).filter_by(name=name).first()
            return self._row_to_dict(config)
        except Exception as e:  # noqa: BLE001
            self._safe_rollback()
            # 2026-10-02（REQ-261001145152-3982 审查）：**失败必须可见**。
            # 原先这里 `except Exception: … return None/0` 是**静默**的 —— 而调用方会把它
            # 读成业务事实，且这两种解释的后果完全不同：
            #   · `apscheduler_service` 用它算 `expected`（启用任务数）→ 读失败得 0，
            #     会被当成"没有任务要调度"（该服务里本就有
            #     `reconcile_refuses_empty_desired_set` 这类护栏，说明该失败模式是已知的）；
            #   · `scheduler_config_service` 用它判断"任务是否存在"→ 读失败得 None，
            #     会被当成"不存在"而**重复创建**。
            # 与同文件 `list_tasks` 的既有做法对齐：**记 error 再返回**（返回值不变，
            # 不改调用方语义，只是不再让失败无声无息）。
            logger.error(f"get_task_by_name 读取失败（返回 None，调用方无法与'任务不存在'区分）: name={name}: {e}", exc_info=True)
            return None

    def list_tasks(self, enabled_only: bool = False) -> List[Dict[str, Any]]:
        try:
            query = self.session.query(SchedulerTaskConfig)
            if enabled_only:
                query = query.filter_by(is_enabled=True)
            return [self._row_to_dict(r) for r in query.all()]
        except Exception as e:
            # 不静默（2026-09-13）：此处曾吞异常返回 []，导致调用方把"读失败"当"没有任务"，
            # 进而清空 APScheduler jobstore（调度静默停摆）。
            logger.error(f"list_tasks 读取失败（返回空列表，调用方需自行判定）: {e}", exc_info=True)
            self._safe_rollback()
            return []

    def count_tasks(self, enabled_only: bool = False) -> int:
        try:
            query = self.session.query(func.count(SchedulerTaskConfig.id))
            if enabled_only:
                query = query.filter_by(is_enabled=True)
            return query.scalar() or 0
        except Exception as e:  # noqa: BLE001
            self._safe_rollback()
            # 2026-10-02（REQ-261001145152-3982 审查）：**这一处返回 0 最危险** —— 原先静默，
            # 而调用方 `apscheduler_service` 拿它算 `expected`（启用任务数）：
            # 读失败得 0 会被当成"没有任务要调度"（该服务里本就有
            # `reconcile_refuses_empty_desired_set` 这类护栏，说明该失败模式是已知的）。
            # 与同文件 `list_tasks` 对齐：**记 error 再返回**（返回值不变，只让失败可见）。
            logger.error(f"count_tasks 读取失败（返回 0，调用方无法与'没有任务'区分）: "
                         f"enabled_only={enabled_only}: {e}", exc_info=True)
            return 0

    def enable_task(self, task_id: int) -> bool:
        task = self.get_task(task_id)
        if task is None:
            raise ValueError(f"Task {task_id} not found")
        next_run = _calc_next_run_time(task["cron_expression"])
        try:
            config = self.session.get(SchedulerTaskConfig, task_id)
            config.is_enabled = True
            config.next_run_at = next_run
            self.session.commit()
            return True
        except Exception:
            self.session.rollback()
            raise

    def disable_task(self, task_id: int) -> bool:
        try:
            config = self.session.get(SchedulerTaskConfig, task_id)
            if config is None:
                return False
            config.is_enabled = False
            self.session.commit()
            return True
        except Exception:
            self.session.rollback()
            raise

    # ── Run Lifecycle ──

    def create_run(self, task_id: int, started_at: Optional[datetime] = None) -> int:
        # P0-C（2026-09-10 w-23c70356 审计）：started_at 原本硬用"写库时刻"，
        # webhook 路径（先跑完 handler 再写库）因此把 started_at/completed_at 都记成
        # 写库瞬间 → duration_ms 恒为 3~15ms，执行时间列对 Agent OS 委托任务完全失真
        # （实测 market_style_update 真实 elapsed 0.16s、market_daily_snapshot 3.3s，
        # 而 run.duration_ms 显示 11ms/13ms）。允许调用方传入真实开始时刻；
        # 不传（APScheduler 路径在跑任务前调用）保持 now() 原语义不变。
        now = datetime.now(timezone.utc)
        run = SchedulerRun(
            task_id=task_id,
            status="running",
            started_at=started_at or now,
        )
        try:
            self.session.add(run)
            config = self.session.get(SchedulerTaskConfig, task_id)
            if config:
                config.last_run_at = now
                config.last_status = "running"
            self.session.commit()
            self.session.refresh(run)
            return run.id
        except Exception:
            self.session.rollback()
            raise

    def complete_run(
        self,
        run_id: int,
        success: bool = True,
        result: Optional[Dict[str, Any]] = None,
        error: Optional[str] = None,
        completed_at: Optional[datetime] = None,
    ) -> bool:
        status = "success" if success else "failed"
        # P0-C：同上，允许传入真实完成时刻（webhook 路径在 handler 结束后写库，
        # 不传时用 now()，与 APScheduler 路径原语义一致）。
        now = completed_at or datetime.now(timezone.utc)
        try:
            run = self.session.get(SchedulerRun, run_id)
            if run is None:
                return False
            run.status = status
            run.completed_at = now
            # result 列是 JSONB，而 handler 返回值常含 date/datetime/Decimal/dataclass——
            # 直接赋值会让 SQLAlchemy 的 json 序列化抛 TypeError（实测 2026-09-13：
            # ingest_events_daily 的 712 条事件结果里带 datetime.date → UPDATE 失败
            # → **任务本身成功却被记成 failed**，并刷出 6 张"date is not JSON serializable"
            # 错误事件卡；同类 autoflush/StatementError 也由此而来）。
            # 统一先过 sanitize_for_json（adapters.shared.json_helpers）。
            run.result = _json_safe(result)
            run.error = error
            if run.started_at:
                run.duration_ms = int((now - run.started_at).total_seconds() * 1000)

            config = self.session.get(SchedulerTaskConfig, run.task_id)
            if config:
                config.last_status = status
                config.last_error = error
                # Agent OS 托管伪任务（cron 保留字）无真实调度，跳过 next_run 计算
                # （2026-09-01 修复：complete_run 曾因 parse_cron 抛异常致 run 卡 running）
                if not str(config.cron_expression).startswith("managed_by_agent_"):
                    config.next_run_at = _calc_next_run_time(config.cron_expression)

            self.session.commit()
            return True
        except Exception:
            self.session.rollback()
            raise

    def record_missed_run(
        self,
        task_id: int,
        scheduled_run_time: Optional[datetime] = None,
        note: Optional[str] = None,
    ) -> Optional[int]:
        """把「被 APScheduler 跳过（missed）」写成一条 run 记录。

        REQ-261004154902-a7cd t5（FR-4 / FR-8）。

        为什么需要：APScheduler 对超出 misfire 宽限的 trigger **只打一行纯文本 warning
        就跳过**——不写 `scheduler_runs`、不更新 `last_status`、不告警。实证（2026-10-03 /
        10-04）：每日数据质量检查分别晚 5:23 / 24:42 被静默跳过，库里查不到任何痕迹，
        `last_status` 还停在前几天的 success。

        本方法让「该跑没跑」在库里可见：写一条 `status='missed'` 的 run（列是 String(50)，
        无需 DDL），并把任务的 `last_status` 标成 missed、`last_error` 写明跳过原因。
        **不动 `next_run_at`**（那是 APScheduler 排期的事实，不该由记账逻辑改）。

        Args:
            task_id: `quant.scheduler_tasks.id`
            scheduled_run_time: 被跳过的那个排班时刻（APScheduler 事件带出）
            note: 跳过原因（如 `missed by 0:08:37`）

        Returns:
            int: 新建的 run id；失败返回 None（记账失败不许影响调度）
        """
        now = datetime.now(timezone.utc)
        started = scheduled_run_time or now
        message = note or "missed: APScheduler 判定超出 misfire 宽限，已跳过"
        try:
            run = SchedulerRun(
                task_id=task_id,
                status="missed",
                started_at=started,
                completed_at=now,
                result={"missed": True, "scheduled_run_time": str(started), "note": message},
                error=message,
            )
            self.session.add(run)

            config = self.session.get(SchedulerTaskConfig, task_id)
            if config:
                config.last_status = "missed"
                config.last_error = message

            self.session.commit()
            self.session.refresh(run)
            return run.id
        except Exception as exc:  # noqa: BLE001 - 记账失败不得击穿调度线程
            self.session.rollback()
            logger.error("record_missed_run 失败 task_id=%s: %s", task_id, exc)
            return None

    def get_run(self, run_id: int) -> Optional[Dict[str, Any]]:
        try:
            run = self.session.get(SchedulerRun, run_id)
            return self._row_to_dict(run)
        except Exception:
            self._safe_rollback()
            return None

    def list_runs(
        self,
        task_id: Optional[int] = None,
        limit: int = 50,
        offset: int = 0,
        statuses: Optional[List[str]] = None,
        date_filter: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        try:
            query = self.session.query(SchedulerRun)
            if task_id is not None:
                query = query.filter(SchedulerRun.task_id == task_id)
            if statuses:
                query = query.filter(SchedulerRun.status.in_(statuses))
            if date_filter:
                query = query.filter(func.date(SchedulerRun.started_at) == date_filter)
            query = query.order_by(SchedulerRun.started_at.desc()).offset(offset).limit(limit)
            return [self._row_to_dict(r) for r in query.all()]
        except Exception:
            self._safe_rollback()
            return []

    def count_runs(
        self,
        task_id: Optional[int] = None,
        statuses: Optional[List[str]] = None,
        date_filter: Optional[str] = None,
    ) -> int:
        try:
            query = self.session.query(func.count(SchedulerRun.id))
            if task_id is not None:
                query = query.filter(SchedulerRun.task_id == task_id)
            if statuses:
                query = query.filter(SchedulerRun.status.in_(statuses))
            if date_filter:
                query = query.filter(func.date(SchedulerRun.started_at) == date_filter)
            return query.scalar() or 0
        except Exception:
            self._safe_rollback()
            return 0

    # ── Health Check ──

    def recover_orphan_runs(self, note: str = "孤儿 run：进程重启遗留") -> List[int]:
        """启动时回收上一进程遗留的 running run（闭环为 failed）。

        2026-09-11 w-23c70356：APScheduler 运行在 API 进程内，进程重启会打断 run 的
        收尾记账，run 行会永久停留 running（实例 run 3527 自 2026-09-10 22:00 卡死
        1.9 小时，只能人工闭环）。启动时统一回收，避免僵尸累积与看门狗误报。
        安全性：本进程刚启动时不存在"本进程在跑"的 run；仅跳过 60 秒内创建的行，
        防止与同进程并发启动的 run 竞争。
        """
        try:
            now = datetime.now(timezone.utc)
            guard = now - timedelta(seconds=60)
            rows = (
                self.session.query(SchedulerRun)
                .filter(SchedulerRun.status == "running")
                .all()
            )
            recovered: List[int] = []
            touched_tasks: set = set()
            for run in rows:
                if run.started_at is not None and run.started_at > guard:
                    continue  # 刚创建，可能仍在执行（同进程并发）
                run.status = "failed"
                run.completed_at = now
                run.error = note
                if run.started_at:
                    run.duration_ms = int((now - run.started_at).total_seconds() * 1000)
                recovered.append(run.id)
                touched_tasks.add(run.task_id)

            # 同步回写任务行（2026-09-11 w-f436d4ea）：原先只闭环 run 行，任务行的
            # last_status/last_error/next_run_at **一个都不动**。后果三连（实测任务 232
            # 『每日数据质量检查』09-10、09-11 两次被进程重启打断）：
            #   ① 任务列表显示 failed 却**没有任何原因**——原因只躺在 scheduler_runs.error
            #      里，看板与排查入口（scheduler_tasks.last_error）读不到；
            #   ② next_run_at 停在被打断的那次时刻（实测停在 2026-09-11 22:00:00）不推进；
            #   ③ 于是「任务失败」这件事在运维面上表现为「失败且无可解释信息」。
            # 回写口径与 complete_run 保持一致（含 managed_by_agent_ 伪任务跳过 next_run）。
            for task_id in touched_tasks:
                config = self.session.get(SchedulerTaskConfig, task_id)
                if config is None:
                    continue
                config.last_status = "failed"
                config.last_error = note
                if not str(config.cron_expression).startswith("managed_by_agent_"):
                    config.next_run_at = _calc_next_run_time(config.cron_expression)

            if recovered:
                self.session.commit()
            return recovered
        except Exception:
            self.session.rollback()
            raise

    def find_zombie_runs(self, threshold_hours: int = 1) -> List[Dict[str, Any]]:
        try:
            cutoff = datetime.now(timezone.utc) - timedelta(hours=threshold_hours)
            rows = (
                self.session.query(SchedulerRun, SchedulerTaskConfig.name)
                .join(SchedulerTaskConfig, SchedulerRun.task_id == SchedulerTaskConfig.id)
                .filter(
                    SchedulerRun.status == "running",
                    SchedulerRun.started_at < cutoff,
                )
                .all()
            )
            return [
                {
                    "run_id": run.id,
                    "name": name,
                    "started_at": run.started_at.isoformat() if run.started_at else None,
                    "hours_running": (datetime.now(timezone.utc) - run.started_at).total_seconds() / 3600
                    if run.started_at
                    else 0,
                }
                for run, name in rows
            ]
        except Exception:
            self._safe_rollback()
            return []

    def find_missed_tasks(self, threshold_hours: int = 24) -> List[Dict[str, Any]]:
        try:
            cutoff = datetime.now(timezone.utc) - timedelta(hours=threshold_hours)
            # ADR-002（2026-09-01）后 v2 本地 APScheduler 为主调度：已入 job store
            # 且 next_run_time 在未来的任务视为"已排期"，即使 last_run 陈旧也不算
            # missed（切换日 cron 时点已过不补跑是设计内行为，非故障）。
            now_epoch = datetime.now(timezone.utc).timestamp()
            scheduled_task_ids: set = set()
            try:
                # 2026-09-14（REQ-24e15d B4-c5）：原为 Core text() 裸 SQL
                #     SELECT id FROM public.apscheduler_jobs
                #      WHERE id LIKE 'task_%' AND next_run_time > :now_epoch
                # 改为 Core 表达式（见 _APSCHEDULER_JOBS 处的判断说明）：同样的过滤、
                # 同样的绑定参数（now_epoch 仍是 Python float）、同样的 public schema 限定。
                rows = self.session.execute(
                    select(_APSCHEDULER_JOBS.c.id).where(
                        _APSCHEDULER_JOBS.c.id.like('task_%'),
                        _APSCHEDULER_JOBS.c.next_run_time > now_epoch,
                    )
                ).fetchall()
                scheduled_task_ids = {
                    int(r[0].split("_", 1)[1]) for r in rows if "_" in r[0]
                }
            except Exception as e:
                logger.warning(f"apscheduler jobstore query failed, fallback to strict check: {e}")

            rows = (
                self.session.query(SchedulerTaskConfig)
                .filter(
                    SchedulerTaskConfig.is_enabled == True,
                    ~SchedulerTaskConfig.cron_expression.like("managed_by_agent_%"),
                    (SchedulerTaskConfig.last_run_at == None) | (SchedulerTaskConfig.last_run_at < cutoff),
                )
                .all()
            )
            result = []
            for r in rows:
                if r.id in scheduled_task_ids:
                    continue  # 已由本地 APScheduler 排期（next_run 在未来），不算 missed
                result.append({
                    "name": r.name,
                    "cron_expression": r.cron_expression,
                    "last_run_at": r.last_run_at.isoformat() if r.last_run_at else "NEVER",
                })
            return result
        except Exception:
            self._safe_rollback()
            return []

    def find_high_failure_tasks(
        self, days: int = 7, min_runs: int = 3, fail_rate_threshold: float = 0.5
    ) -> List[Dict[str, Any]]:
        try:
            cutoff = datetime.now(timezone.utc) - timedelta(days=days)
            # 排除"孤儿 run"（error 含 孤儿/进程重启 字样）：进程重启打断的 run 是
            # 调度环境事故，不代表任务逻辑失败，计入失败率会造成误报。
            # P0-B 修复（2026-09-10 w-23c70356 审计）：
            # ① 原失败计数 func.sum(func.cast(status=="failed", func.cast(0, func.cast(1, id))))
            #    是非法聚合表达式，实测恒为 0 —— 真失败也测不出来（实证：任务 325
            #    market_style_update 近 7 天 4 次运行 4 次 failed，本方法仍返回 []），
            #    失败率看门狗形同虚设；
            # ② 只统计行级 status，漏掉"行级 success + 内层 result 报错"的静默失败
            #    （同次审计发现 2026-06-04 起 40 条静默失败全部逃过看门狗）。
            # 现改为 case() 显式计数，并把内层失败一并计入 failed。
            inner_failed = or_(
                SchedulerRun.result["status"].astext.in_(["failed", "error"]),
                SchedulerRun.result["success"].astext == "false",
                and_(
                    SchedulerRun.result["status"].astext.is_(None),
                    SchedulerRun.result["error"].astext.isnot(None),
                ),
            )
            is_failed = case(
                (or_(SchedulerRun.status == "failed", inner_failed), 1),
                else_=0,
            )
            rows = (
                self.session.query(
                    SchedulerTaskConfig.name,
                    func.count(SchedulerRun.id).label("total"),
                    func.sum(is_failed).label("failed"),
                )
                .join(SchedulerRun, SchedulerRun.task_id == SchedulerTaskConfig.id)
                .filter(
                    SchedulerRun.started_at > cutoff,
                    or_(
                        SchedulerRun.error.is_(None),
                        ~SchedulerRun.error.like("%孤儿%"),
                        ~SchedulerRun.error.like("%进程重启%"),
                    ),
                )
                .group_by(SchedulerTaskConfig.name)
                .having(func.count(SchedulerRun.id) >= min_runs)
                .all()
            )
            result = []
            for name, total, failed in rows:
                total = total or 0
                failed = failed or 0
                if total > 0 and failed / total > fail_rate_threshold:
                    result.append({
                        "name": name,
                        "total": total,
                        "failed": failed,
                        "fail_rate": failed / total,
                    })
            return result
        except Exception:
            self._safe_rollback()
            return []

    def count_enabled_tasks(self) -> int:
        try:
            return (
                self.session.query(func.count(SchedulerTaskConfig.id))
                .filter(SchedulerTaskConfig.is_enabled == True)
                .scalar()
                or 0
            )
        except Exception:
            self._safe_rollback()
            return 0