"""
V13策略模拟交易系统 - 主执行脚本（完整版）

功能：
1. 训练XGBoost模型
2. 每日检查是否需要调仓
3. 获取最新数据并计算85个因子
4. 模型预测Top 5股票
5. 执行模拟交易
6. 生成监控报告
"""

import os
# 必须在所有导入之前设置，避免 OpenMP/MKL 与 XGBoost 冲突导致段错误
import sys
import math
import yaml
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import json
from pathlib import Path
from dotenv import load_dotenv
import structlog

# 加载环境变量（必须在导入其他模块之前）
load_dotenv()

logger = structlog.get_logger(__name__)

# 添加项目路径

from infrastructure.services.service_factory import ServiceFactory
from live_trading.factor_calculator import V13FactorCalculator
from live_trading.v14_factor_calculator import V14FactorCalculator

# 因子计算器注册表：新策略引入全新因子体系时在此注册一行
FACTOR_CALCULATORS = {
    'v13': V13FactorCalculator,
    'v14': V14FactorCalculator,
}
from live_trading.simulation_broker import SimulationBroker
from adapters.outbound.repositories import SimulationORMRepository
from live_trading.v13_factors import get_factor_names
from live_trading.risk_control import RiskController
from infrastructure.persistence.database.engine import init_engine, get_engine

# 可选依赖：飞书通知（如果导入失败则禁用）
try:
    from application.notification.notification_factory import get_notification_facade
    _notification_available = True
except ImportError:
    logger.warning("Notification system not available")
    _notification_available = False

# 2026-10-04（REQ-261004154902-a7cd t2 / FR-1 / FR-2）：
# 结果契约与失败出口。动因见 application/observability/run_outcome.py 的模块 docstring——
# 本文件此前**丢弃** rebalance() 的返回值、并把异常吞成 success。
from application.observability import RunOutcome
from application.observability.failure_sink import SEVERITY_HIGH, report_failure
from application.observability.run_outcome import (
    ACTION_HOLD,
    ACTION_REBALANCE,
    ACTION_STOP_LOSS,
    FAILED_REASONS,
    REASON_FACTOR_EMPTY,
    REASON_MODEL_NOT_LOADED,
    REASON_NOT_DUE,
    REASON_NOT_TRADING_DAY,
    REASON_REBALANCE_FAILED,
    REASON_STOP_LOSS_FAILED,
)

import xgboost as xgb
import psycopg2


def judge_trading_day(day, *, kline_exists_on_date, latest_kline_date, today):
    """判定某天是否为交易日（纯函数，可单测）。

    2026-09-11（w-f4aa1f6a 步2）：唯一实现已提升到
    application.services.trading_day_guard.judge_trading_day，
    这里保留同名委托以兼容既有调用与单测（语义未变）：
    - 周末 → False；未来日期 → False
    - 当天日K已落库 → True（历史日期的主要判据，精确覆盖法定节假日）
    - 当天日K未落库且判定对象是"今天"：盘中场景（日K 17:40 才更新），
      近期市场活跃（7 个自然日内有K线）→ True
    - 其他（过去的工作日无K线 = 节假日；长期停市/数据断供）→ False
    """
    from application.services.trading_day_guard import judge_trading_day as _judge

    return _judge(
        day,
        kline_exists_on_date=kline_exists_on_date,
        latest_kline_date=latest_kline_date,
        today=today,
    )


class SimulationTrader:
    """V13策略模拟交易器（使用数据库持久化）"""

    @staticmethod
    def _sanitize_float(value):
        """清理浮点数：将 NaN/Inf 转换为 None，避免 JSON 序列化错误"""
        if isinstance(value, (int, float)):
            if math.isnan(value) or math.isinf(value):
                return None
        return value

    def __init__(self, config_path='live_trading/config_simulation.yaml',
                 account_name='default', factor_calculator='v13'):
        """初始化

        Args:
            config_path: 交易参数配置文件路径
            account_name: 数据库账户名（必须在 _load_account_from_db 之前确定）
            factor_calculator: 因子计算器，FACTOR_CALCULATORS 注册表键名或实例
        """
        from infrastructure.services.service_factory import ServiceFactory

        self.config = self._load_config(config_path)
        self.kline_repo = ServiceFactory.get_kline_repository()

        # 因子计算器：注册表键名或直接传实例
        if isinstance(factor_calculator, str):
            if factor_calculator not in FACTOR_CALCULATORS:
                raise ValueError(
                    f"未知 factor_calculator: {factor_calculator}，"
                    f"可用: {sorted(FACTOR_CALCULATORS)}"
                )
            self.factor_calc = FACTOR_CALCULATORS[factor_calculator]()
        else:
            self.factor_calc = factor_calculator

        self.broker = SimulationBroker(
            commission_rate=self.config['trading']['commission_rate'],
            slippage_rate=self.config['trading']['slippage_rate']
        )

        # 初始化 SQLAlchemy Engine(如果未初始化)
        try:
            get_engine()
        except RuntimeError:
            init_engine(pool_size=5, max_overflow=10)

        # 让 Repository 自己从 Engine 池获取连接
        self.repo = SimulationORMRepository()

        self.model = None
        self.valid_factors = None
        # t2：最近一次调仓通知的失败原因（None = 未发或已送达）
        self._last_notify_error = None

        # 模型文件路径（load_model 读取，可在构造后由调用方覆盖）
        base_dir = Path(__file__).parent
        self.model_path = str(base_dir / 'models' / 'v13_model.json')
        self.factors_path = str(base_dir / 'models' / 'valid_factors.json')

        # 账户名称（必须在 _load_account_from_db 之前赋值）
        self.account_name = account_name

        # 初始化风险控制
        self.risk_controller = RiskController(self.config['risk_control'])

        # 初始化通知系统（使用新的 DDD 通知系统）
        if _notification_available:
            self.notification_facade = get_notification_facade()
            logger.info("通知系统已启用")
        else:
            self.notification_facade = None
            logger.warning("通知系统不可用")

        # 2026-09-05 修复：b7ddddf0 (notification DDD refactor) 重写 __init__ 尾部时
        # 误删了 _load_account_from_db() 调用，导致 portfolio/cash/peak_value 从未初始化，
        # v13/v14 每日检查全部 AttributeError ('SimulationTrader' object has no attribute 'portfolio')。
        # 必须在构造时加载账户状态（交易记录重建持仓、现金、峰值资产）。
        self._load_account_from_db()

        logger.info(f"模拟交易器初始化完成: {self.account_name}, 现金=¥{self.cash:,.2f}, 持仓={len(self.portfolio)}只")

    def _load_config(self, config_path):
        """加载配置"""
        with open(config_path, 'r', encoding='utf-8') as f:
            return yaml.safe_load(f)

    def _setup_logging(self):
        """设置日志"""
        from infrastructure.logging import configure_structured_logging
        import structlog

        log_dir = Path(self.config['logging']['log_dir'])
        log_dir.mkdir(parents=True, exist_ok=True)

        log_file = log_dir / f"simulation_{datetime.now().strftime('%Y%m%d')}.log"

        # 使用结构化日志配置
        configure_structured_logging(
            level=self.config['logging']['level'],
            json_format=False,
            enable_trace_id=True
        )

    def _load_account_from_db(self):
        """从数据库加载账户状态"""
        account = self.repo.get_account(self.account_name)

        if account:
            # 兼容ORM对象和dict
            if hasattr(account, 'cash_available'):
                # ORM对象
                self.cash = float(account.cash_available or 0) + float(account.cash_frozen or 0)
                self.peak_value = float(account.peak_value)
                self.last_rebalance_date = str(account.last_rebalance_date) if account.last_rebalance_date else None
            else:
                # dict
                self.cash = float(account.get('cash_available', 0) or 0) + float(account.get('cash_frozen', 0) or 0)
                self.peak_value = float(account['peak_value'])
                self.last_rebalance_date = str(account['last_rebalance_date']) if account['last_rebalance_date'] else None

            # ✅ 从交易记录重建持仓（单一数据源）
            self.portfolio = self._rebuild_portfolio_from_trades()

            # 验证持仓表一致性
            db_positions = self.repo.get_all_positions(self.account_name)
            db_count = len(db_positions)
            real_count = len(self.portfolio)

            if db_count != real_count:
                logger.warning(f"⚠️ 持仓不一致: 数据库{db_count}只 vs 交易记录{real_count}只")
                logger.warning(f"   将在调仓后自动修复")

            logger.info(f"从数据库加载账户: {len(self.portfolio)}只持仓（从交易记录重建）")
        else:
            # 初始化账户
            self.cash = self.config['initial_capital']
            self.peak_value = self.cash
            self.last_rebalance_date = None
            self.portfolio = {}
            logger.info(f"初始化新账户: ¥{self.cash:,.2f}")

    def _rebuild_portfolio_from_trades(self):
        """从交易记录重建持仓（单一数据源）"""
        from infrastructure.persistence.database.engine import get_engine

        engine = get_engine()
        conn = engine.raw_connection()
        try:
            cursor = conn.cursor()

            # 2026-08-12：action 用 UPPER() 匹配——历史上 AccountTradingService
            # 写入过小写 'buy'/'sell'（8/5 三笔卖出因此被无视 → 幽灵持仓注水估值）。
            # 写入侧已由 repo.normalize_action 统一大写，此处兼容存量脏数据。
            query = '''
                SELECT
                    symbol,
                    SUM(CASE WHEN UPPER(action) = 'BUY' THEN shares
                             WHEN UPPER(action) = 'SELL' THEN -shares
                             ELSE 0 END) as total_shares,
                    SUM(CASE WHEN UPPER(action) = 'BUY' THEN shares * filled_price END) /
                    NULLIF(SUM(CASE WHEN UPPER(action) = 'BUY' THEN shares END), 0) as avg_price
                FROM quant.simulation_trades
                WHERE account_name = %s
                GROUP BY symbol
                HAVING SUM(CASE WHEN UPPER(action) = 'BUY' THEN shares
                                WHEN UPPER(action) = 'SELL' THEN -shares
                                ELSE 0 END) > 0
            '''

            cursor.execute(query, (self.account_name,))
            rows = cursor.fetchall()
            cursor.close()

            portfolio = {}
            for row in rows:
                if isinstance(row, dict):
                    symbol = row['symbol']
                    shares = int(row['total_shares'])
                    avg_price = float(row['avg_price'])
                else:
                    symbol = row[0]
                    shares = int(row[1])
                    avg_price = float(row[2])

                portfolio[symbol] = {
                    'shares': shares,
                    'avg_price': avg_price
                }

            logger.info(f"从交易记录重建持仓: {len(portfolio)}只股票")
            return portfolio
        finally:
            conn.close()  # 确保连接归还到池

    def _validate_data_consistency(self):
        """调仓前数据一致性检查"""
        logger.info("\n数据一致性检查...")

        # 1. 从交易记录计算真实持仓
        real_portfolio = self._rebuild_portfolio_from_trades()

        # 2. 检查数据库持仓表
        db_positions = self.repo.get_all_positions(self.account_name)
        db_symbols = set()
        for pos in db_positions:
            symbol = pos.symbol if hasattr(pos, 'symbol') else pos['symbol']
            db_symbols.add(symbol)

        # 3. 对比
        real_symbols = set(real_portfolio.keys())
        missing = real_symbols - db_symbols
        extra = db_symbols - real_symbols

        if missing or extra:
            logger.warning(f"⚠️ 数据不一致！")
            if missing:
                logger.warning(f"   缺失持仓: {missing}")
            if extra:
                logger.warning(f"   多余持仓: {extra}")
            logger.warning(f"   自动修复中...")

            # 自动修复：清空并重建
            self.repo.clear_all_positions(self.account_name)
            for symbol, pos in real_portfolio.items():
                self.repo.upsert_position(
                    account_name=self.account_name,
                    symbol=symbol,
                    shares_total=pos['shares'],
                    avg_cost=pos['avg_price']
                )
            logger.info(f"✅ 已自动修复持仓表")
        else:
            logger.info(f"✅ 数据一致性检查通过（{len(real_symbols)}只持仓）")

        # 4. 更新内存持仓
        self.portfolio = real_portfolio

    def _save_account_to_db(self):
        """保存账户状态到数据库"""
        # ✅ 从交易记录重建持仓，确保数据一致性
        self.portfolio = self._rebuild_portfolio_from_trades()

        total_value = self._calculate_total_value_from_portfolio()
        cumulative_return = (total_value / self.config['initial_capital'] - 1)
        max_drawdown = (total_value / self.peak_value - 1) if self.peak_value > 0 else 0

        # ✅ 严重告警：检查现金是否为负（透支）
        if self.cash < 0:
            logger.error(f"🚨 严重警告：账户现金为负 ¥{self.cash:,.2f}！")
            logger.error(f"   初始资金: ¥{self.config['initial_capital']:,.2f}")
            logger.error(f"   总资产: ¥{total_value:,.2f}")
            logger.error(f"   透支金额: ¥{abs(self.cash):,.2f}")
            logger.error(f"   请立即检查交易记录，可能存在超买问题！")

        # ✅ 警告：检查总资产是否低于初始资金的50%
        if total_value < self.config['initial_capital'] * 0.5:
            logger.warning(f"⚠️  警告：总资产已跌破初始资金的50%")
            logger.warning(f"   当前总资产: ¥{total_value:,.2f}")
            logger.warning(f"   累计亏损: {cumulative_return:.2%}")

        position_value = total_value - self.cash
        self.repo.update_account(
            account_name=self.account_name,
            cash_available=self.cash,
            total_value=total_value,
            peak_value=self.peak_value,
            cumulative_return=cumulative_return,
            max_drawdown=max_drawdown,
            position_value=position_value,
            last_rebalance_date=self.last_rebalance_date
        )

        # ✅ 先清空持仓表，再重建（防止残留）
        self.repo.clear_all_positions(self.account_name)

        # 保存持仓
        for symbol, pos in self.portfolio.items():
            self.repo.upsert_position(
                account_name=self.account_name,
                symbol=symbol,
                shares_total=pos['shares'],
                avg_cost=pos['avg_price']
            )

        # T+1 结转：当日买入的份额当日不可卖
        self.repo.settle_t1(self.account_name)

        # ✅ 保存每日快照（按账户隔离，写入 simulation_equity_snapshot）
        self._save_daily_snapshot(total_value, cumulative_return)

    def _should_write_snapshot(self, check_date=None) -> bool:
        """是否应写入当日净值快照（2026-09-11，w-f4aa1f6a 加守卫）。

        实证：2026-08-08（**周六**）02:00:09，5 个账户在同一秒内被写入快照（值还与周五不同），
        来源是周六 02:00 的任务链在结算时**无条件**落快照（本文件此前没有任何交易日校验）。
        非交易日快照会污染下游：risk_metrics 的波动率/alpha/IR 由「相邻快照差分的日收益」算出，
        凭空多出一天会把跨日涨跌切成两段；基准对齐也会出现「净值有、基准无」的伪缺口。

        校验失败时**仍写入**（宁可多一条，也不丢真正的交易日快照——交易日快照缺失是更难补救的）。
        """
        d = check_date or datetime.now().strftime('%Y-%m-%d')
        # 2026-09-11（w-f4aa1f6a 步2）：收敛到 TradingDayGuard 唯一入口。
        # 原来走 TradingCalendarService：其内部 Redis→内存→工作日→provider 的
        # 路径在工作日兜底时会把法定节假日当交易日（且不告知调用方），
        # 正是 2026-08-08 周末合成快照那类问题的温床。护栏改为 K 线数据驱动，
        # 并显式返回判定来源与降级标记。
        from application.services.trading_day_guard import TradingDayGuard

        verdict = TradingDayGuard.should_write_daily(d)
        if not verdict.is_trading_day:
            logger.info(
                f"[{self.account_name}] {d} 非交易日"
                f"（{verdict.source}: {verdict.reason}）→ 跳过净值快照写入"
            )
            return False
        if verdict.degraded:
            logger.warning(
                f"[{self.account_name}] {d} 交易日判定降级"
                f"（{verdict.source}: {verdict.reason}），按交易日处理"
            )
        return True

    def _save_daily_snapshot(self, total_value: float, cumulative_return: float):
        """保存每日账户快照到 simulation_equity_snapshot 表（按账户隔离）

        修复：旧实现写 quant.account_balance（无账户列），多账户同日互相覆盖。
        2026-09-11 追加：非交易日不写（见 _should_write_snapshot 的实证说明）。
        """
        if not self._should_write_snapshot():
            return
        position_value = total_value - self.cash
        drawdown = (total_value / self.peak_value - 1) if self.peak_value > 0 else 0
        self.repo.upsert_equity_snapshot(
            self.account_name,
            cash=self.cash,
            position_value=position_value,
            total_value=total_value,
            cumulative_return=cumulative_return,
            drawdown=drawdown,
        )
        logger.info(f"保存每日快照: {self.account_name}, 总资产=¥{total_value:,.2f}")

    def _calculate_total_value_from_portfolio(self):
        """从持仓计算总资产"""
        if not self.portfolio:
            return self.cash

        # 获取当前价格
        symbols = list(self.portfolio.keys())
        prices = {}
        for symbol in symbols:
            try:
                latest = self.kline_repo.get_latest_daily_kline(symbol)
                if latest is not None and not latest.is_empty():
                    prices[symbol] = float(latest['close'][0])
                else:
                    prices[symbol] = self.portfolio[symbol]['avg_price']
            except (AttributeError, KeyError, IndexError, TypeError) as e:
                logger.warning(f"获取 {symbol} 最新价格失败，使用均价: {e}")
                prices[symbol] = self.portfolio[symbol]['avg_price']

        # 计算持仓市值
        portfolio_value = sum(
            self.portfolio[symbol]['shares'] * prices.get(symbol, self.portfolio[symbol]['avg_price'])
            for symbol in self.portfolio
        )

        return self.cash + portfolio_value

    def _get_stock_pool(self, limit=200):
        """
        获取创业板股票池

        过滤条件：
        1. 排除ST股票（财务异常、退市风险）
        2. 排除*ST股票（严重财务异常）
        3. 排除退市股票
        4. 日均成交额 >= 1亿（保证流动性，过滤超小盘股）
        """
        # 兼容ORM和非ORM Repository
        from infrastructure.persistence.database.engine import get_engine
        engine = get_engine()
        conn = engine.raw_connection()
        try:
            cursor = conn.cursor()

            query = f'''
                WITH latest_kline AS (
                    SELECT DISTINCT ON (symbol)
                        symbol,
                        close,
                        volume,
                        amount,
                        turnover_rate,
                        trade_date
                    FROM quant.daily_klines
                    WHERE trade_date >= CURRENT_DATE - INTERVAL '10 days'
                    ORDER BY symbol, trade_date DESC
                )
                SELECT s.symbol, s.name
                FROM quant.stocks s
                INNER JOIN latest_kline k ON s.symbol = k.symbol
                WHERE s.symbol LIKE '3%'
                  AND s.name NOT LIKE '%ST%'                    -- 排除所有ST股票
                  AND s.name NOT LIKE '*%'                      -- 排除退市整理股票
                  AND s.name NOT LIKE '%退%'                    -- 排除退市相关
                  AND k.amount >= 100000000                     -- 日成交额 >= 1亿
                  AND k.volume > 0                              -- 有成交量
                ORDER BY k.amount DESC                          -- 按成交额排序，优先流动性好的
                LIMIT {limit}
            '''

            cursor.execute(query)
            stocks = cursor.fetchall()
            cursor.close()

            # 处理字典或元组返回值
            if stocks and isinstance(stocks[0], dict):
                return [{'symbol': s['symbol'], 'name': s['name']} for s in stocks]
            else:
                return [{'symbol': s[0], 'name': s[1]} for s in stocks]
        finally:
            conn.close()  # 确保连接归还到池

    def _get_historical_data(self, symbols, start_date, end_date):
        """
        获取历史K线数据（用于模型训练）

        直接查询数据库，避免逐个调用get_latest()

        Args:
            symbols: 字符串列表 ['300001', '300002'] 或字典列表 [{'symbol': '300001'}, ...]
        """
        import pandas as pd

        logger.info(f"查询 {len(symbols)} 只股票，时间范围 {start_date} -> {end_date}")

        # 支持两种输入格式
        if isinstance(symbols[0], dict):
            symbol_list = [s['symbol'] for s in symbols]
        else:
            symbol_list = symbols

        placeholders = ','.join(['%s'] * len(symbol_list))

        # 兼容ORM和非ORM Repository
        from infrastructure.persistence.database.engine import get_engine
        engine = get_engine()
        conn = engine.raw_connection()
        try:
            cursor = conn.cursor()
            query = f'''
                SELECT
                    symbol,
                    trade_date as date,
                    open,
                    high,
                    low,
                    close,
                    volume,
                    COALESCE(turnover_rate, 0) as turnover_rate
                FROM quant.daily_klines
                WHERE symbol IN ({placeholders})
                  AND trade_date BETWEEN %s AND %s
                ORDER BY symbol, trade_date
            '''

            cursor.execute(query, symbol_list + [start_date, end_date])
            rows = cursor.fetchall()
            cursor.close()

            if not rows:
                logger.warning("未查询到任何K线数据")
                return pd.DataFrame()

            # 转换为DataFrame
            if isinstance(rows[0], dict):
                df = pd.DataFrame(rows)
            else:
                df = pd.DataFrame(rows, columns=['symbol', 'date', 'open', 'high', 'low', 'close', 'volume', 'turnover_rate'])

            df['date'] = pd.to_datetime(df['date'])

            logger.info(f"获取到 {len(df)} 条K线数据，{df['symbol'].nunique()} 只股票")
            return df
        finally:
            conn.close()  # 确保连接归还到池

    def train_model(self, train_start='2025-06-01', train_end='2026-06-01', stock_limit=200, ic_threshold=0.005, xgb_params=None):
        """
        训练模型

        Args:
            train_start: 训练开始日期
            train_end: 训练结束日期
            stock_limit: 股票池大小（默认200只，提高模型泛化能力）
            ic_threshold: IC筛选阈值（默认0.005，保留更多因子）
            xgb_params: XGBoost自定义参数（dict），用于超参数优化
        """
        logger.info(f"开始训练模型: {train_start} -> {train_end}")
        logger.info(f"股票池大小: {stock_limit}只, IC阈值: {ic_threshold}")

        # 1. 获取股票池（扩大到200只）
        stocks = self._get_stock_pool(limit=stock_limit)
        logger.info(f"获取股票池: {len(stocks)}只")

        # 2. 获取训练数据（使用日期范围查询，不用get_latest）
        logger.info("获取训练数据...")
        train_data = self._get_historical_data(stocks, train_start, train_end)

        if train_data.empty:
            raise ValueError("训练数据为空")

        # 3. 计算因子
        logger.info("计算因子...")
        train_data = self.factor_calc.calculate_factors(train_data)

        # 4. 准备标签（未来5日收益）
        logger.info("准备标签...")
        train_data = train_data.sort_values(['symbol', 'date'])
        train_data['label'] = train_data.groupby('symbol')['close'].transform(
            lambda x: x.pct_change(5).shift(-5)
        )

        # 5. 筛选有效因子
        logger.info("筛选有效因子...")
        all_factors = get_factor_names()
        self.valid_factors = self._select_factors(train_data, all_factors, ic_threshold=ic_threshold)

        # 6. 训练模型
        logger.info("训练XGBoost模型...")
        train_clean = train_data.dropna(subset=['label'] + self.valid_factors)

        X_train = train_clean[self.valid_factors]
        y_train = train_clean['label']

        logger.info(f"训练数据: {len(train_clean)}条, {len(self.valid_factors)}个因子")
        logger.info(f"X_train shape: {X_train.shape}, y_train shape: {y_train.shape}")

        # 检查是否有无效值
        if X_train.isnull().any().any():
            logger.warning("X_train 包含 NaN 值")
        if y_train.isnull().any():
            logger.warning("y_train 包含 NaN 值")

        # 使用自定义参数或默认参数
        if xgb_params:
            logger.info(f"使用自定义XGBoost参数: {xgb_params}")
            default_params = {
                'objective': 'reg:squarederror',
                'random_state': 42,
                'n_jobs': 1  # 使用单线程避免段错误
            }
            default_params.update(xgb_params)
            self.model = xgb.XGBRegressor(**default_params)
        else:
            self.model = xgb.XGBRegressor(
                objective='reg:squarederror',
                max_depth=5,
                learning_rate=0.05,
                n_estimators=100,
                subsample=0.8,
                colsample_bytree=0.8,
                random_state=42,
                n_jobs=1  # 使用单线程避免段错误
            )

        logger.info("开始拟合模型...")
        self.model.fit(X_train, y_train, verbose=False)
        logger.info(f"模型训练完成: {len(train_clean)}条训练数据, {len(self.valid_factors)}个有效因子")

        # 7. 保存模型
        model_dir = Path('live_trading/models')
        model_dir.mkdir(parents=True, exist_ok=True)
        model_file = model_dir / 'v13_model.json'
        self.model.save_model(str(model_file))

        # 保存有效因子列表
        factors_file = model_dir / 'valid_factors.json'
        with open(factors_file, 'w') as f:
            json.dump(self.valid_factors, f)

        # 保存训练信息
        train_info = {
            'train_start': train_start,
            'train_end': train_end,
            'stock_count': len(stocks),
            'sample_count': len(train_clean),
            'factor_count': len(self.valid_factors),
            'train_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        info_file = model_dir / 'train_info.json'
        with open(info_file, 'w') as f:
            json.dump(train_info, f, indent=2)

        logger.info(f"模型已保存: {model_file}")
        logger.info(f"训练信息: {stock_limit}只股票, {len(train_clean)}条样本, {len(self.valid_factors)}个因子")

    def _select_factors(self, data, factors, ic_threshold=0.01):
        """
        筛选有效因子

        Args:
            data: 训练数据
            factors: 候选因子列表
            ic_threshold: IC阈值（默认0.01，更宽松以保留更多因子）

        Note:
            - 大样本量时，单因子IC会降低，但组合预测能力仍强
            - 使用0.01阈值平衡因子数量和质量
            - XGBoost会自动选择重要因子
        """
        ic_results = {}
        valid_data = data.dropna(subset=['label'])

        for factor in factors:
            if factor not in valid_data.columns:
                continue

            factor_data = valid_data[[factor, 'label']].dropna()

            if len(factor_data) < 100:
                continue

            # 检查因子是否为常数
            if factor_data[factor].std() < 1e-10:
                continue

            try:
                # 使用 pandas 的 corr 方法计算 Spearman 相关系数
                # 比 scipy.stats.spearmanr 更稳定
                ic = factor_data[factor].corr(factor_data['label'], method='spearman')

                if not np.isnan(ic) and np.isfinite(ic):
                    ic_results[factor] = ic
            except Exception as e:
                logger.debug(f"因子 {factor} 计算IC失败: {e}")
                continue

        # 筛选有效因子（降低阈值到0.01）
        valid_factors = [f for f, ic in ic_results.items() if abs(ic) > ic_threshold]

        logger.info(f"因子筛选: {len(valid_factors)}/{len(factors)}个有效 (IC阈值: {ic_threshold})")

        # 显示Top 10
        sorted_ics = sorted(ic_results.items(), key=lambda x: abs(x[1]), reverse=True)[:10]
        for factor, ic in sorted_ics:
            logger.info(f"  {factor}: IC={ic:.4f}")

        return valid_factors

    def load_model(self):
        """加载已训练的模型（路径来自 self.model_path / self.factors_path）"""
        model_file = Path(self.model_path)
        factors_file = Path(self.factors_path)

        if not model_file.exists():
            raise FileNotFoundError(f"模型文件不存在: {model_file}")
        if not factors_file.exists():
            raise FileNotFoundError(f"因子文件不存在: {factors_file}")

        self.model = xgb.XGBRegressor(n_jobs=1)  # 使用单线程避免段错误
        self.model.load_model(str(model_file))

        with open(factors_file, 'r') as f:
            self.valid_factors = json.load(f)

        logger.info(f"模型加载完成: {len(self.valid_factors)}个因子 ({model_file.name})")

    def _is_trading_day(self, date_str: str) -> bool:
        """
        判断是否是交易日

        Args:
            date_str: 日期字符串 'YYYY-MM-DD'

        Returns:
            bool: 是否是交易日

        2026-08-12 修复：旧实现用"当天日K是否已落库"作唯一判据，但日K 17:40
        才更新，盘中/早盘的调度检查（06:30/14:30/15:30）永远判定"今天不是
        交易日"→ v13/v14 调仓永远跳过且被记为 success。判定逻辑抽为纯函数
        judge_trading_day，这里只负责取数。
        """
        # 2026-09-11（w-f4aa1f6a 步2）：取数 + 判定统一交给 TradingDayGuard
        # （原实现自带一套 cursor 取数 + 失败时"默认周一~周五"的静默降级）
        from application.services.trading_day_guard import TradingDayGuard

        verdict = TradingDayGuard.check(date_str, use_cache=False)
        if verdict.degraded or verdict.source == 'unavailable':
            logger.warning(
                f"交易日判定降级 [{date_str}] source={verdict.source}: {verdict.reason}"
            )
        return verdict.is_trading_day

    def _count_trading_days(self, start_date: str, end_date: str) -> int:
        """
        计算两个日期之间的交易日数量

        Args:
            start_date: 开始日期 'YYYY-MM-DD'
            end_date: 结束日期 'YYYY-MM-DD'

        Returns:
            int: 交易日数量
        """
        start = datetime.strptime(start_date, '%Y-%m-%d')
        end = datetime.strptime(end_date, '%Y-%m-%d')

        count = 0
        current = start
        while current <= end:
            if self._is_trading_day(current.strftime('%Y-%m-%d')):
                count += 1
            current += timedelta(days=1)

        return count

    def _is_rebalance_due(self, current_date):
        """判断是否到达调仓周期（不含交易日校验）"""
        if self.last_rebalance_date is None:
            return True

        # 计算距离上次调仓的交易日天数
        trading_days = self._count_trading_days(self.last_rebalance_date, current_date)

        # 不包括起始日，所以减1
        trading_days -= 1

        return trading_days >= self.config['strategy']['rebalance_days']

    def should_rebalance(self, current_date):
        """判断是否需要调仓（交易日校验 + 调仓周期）"""
        # 1. 检查是否是交易日
        if not self._is_trading_day(current_date):
            logger.info(f"{current_date} 不是交易日，跳过检查")
            return False

        return self._is_rebalance_due(current_date)

    def run_daily_check(self):
        """每日检查（供调度层调用）

        Returns:
            dict: **结果契约**（见 ``application/observability/run_outcome.py``）。
                  既有字段名 ``executed`` / ``reason`` / ``action`` 保持不变（向后兼容），
                  新增 ``ok`` / ``status`` / ``error``：
                  - 跳过（非交易日 / 未到调仓周期）→ ``status='skipped'``，**不是** success；
                  - 失败（模型未加载 / 因子为空 / 调仓抛错 / 止损失败）→ ``status='failed'``
                    且 ``error`` 非空，同时经 FailureSink 主动外发；
                  - 真干成（调仓完成 / 触发止损）→ ``status='success'``。

        2026-10-04（REQ-261004154902-a7cd t2）：此前本方法**丢弃** ``rebalance()`` 的返回值、
        无条件返回 ``executed=True, action='rebalance'``，于是调仓抛错也对外表现为成功
        （实证：9/1–9/11 账户零成交、5 次日检全记 success）。
        """
        today = datetime.now().strftime('%Y-%m-%d')
        logger.info(f"\n{'='*60}")
        logger.info(f"日期: {today}")
        logger.info(f"{'='*60}")

        # 检查模型
        if self.model is None:
            logger.error("模型未加载，请先训练或加载模型")
            self._report_failure(
                REASON_MODEL_NOT_LOADED,
                f"模型未加载（model_path={getattr(self, 'model_path', None)}）",
                context={'date': today},
            )
            return RunOutcome.failed(
                REASON_MODEL_NOT_LOADED,
                f"模型未加载（model_path={getattr(self, 'model_path', None)}）",
                action=ACTION_HOLD,
                executed=False,
            ).to_dict()

        # 交易日校验前置（此前埋在 should_rebalance 里，无法与"未到调仓周期"区分）
        if not self._is_trading_day(today):
            logger.info(f"{today} 不是交易日，跳过检查")
            return RunOutcome.skipped(REASON_NOT_TRADING_DAY).to_dict()

        action = ACTION_HOLD
        detail = {}

        # 1. 检查单股止损
        if self.portfolio:
            prices = self._get_current_prices(list(self.portfolio.keys()), today)
            stop_loss_symbols = self.risk_controller.check_single_stock_stop_loss(
                self.portfolio, prices
            )

            if stop_loss_symbols:
                logger.warning(f"触发单股止损: {stop_loss_symbols}")
                try:
                    self._execute_stop_loss(stop_loss_symbols, prices, today)
                    self._save_account_to_db()
                    action = ACTION_STOP_LOSS
                    detail['stop_loss_symbols'] = list(stop_loss_symbols)
                except Exception as exc:  # noqa: BLE001 - 止损失败必须如实上报
                    logger.error(f"止损执行失败: {exc}", exc_info=True)
                    self._report_failure(
                        REASON_STOP_LOSS_FAILED,
                        exc,
                        context={'date': today, 'symbols': list(stop_loss_symbols)},
                    )
                    return RunOutcome.failed(
                        REASON_STOP_LOSS_FAILED,
                        exc,
                        action=ACTION_STOP_LOSS,
                        detail={'stop_loss_symbols': list(stop_loss_symbols)},
                    ).to_dict()

        # 2. 检查是否需要调仓
        if not self._is_rebalance_due(today):
            last_date = datetime.strptime(self.last_rebalance_date, '%Y-%m-%d')
            days_passed = (datetime.now() - last_date).days
            days_to_next = self.config['strategy']['rebalance_days'] - days_passed
            logger.info(f"距离下次调仓还有 {days_to_next} 天")
            detail['days_to_next'] = days_to_next
            if action == ACTION_STOP_LOSS:
                # 止损是真干成了的事；未到调仓周期不影响这一点
                return RunOutcome.done(ACTION_STOP_LOSS, detail=detail).to_dict()
            return RunOutcome(
                executed=True,
                reason=REASON_NOT_DUE,
                action=ACTION_HOLD,
                detail=detail,
            ).to_dict()

        logger.info("触发调仓条件，开始执行...")
        rebalance_result = self.rebalance(today)

        # ✅ 关键修复（t2）：调仓结果必须被消费，不许再丢弃
        if not isinstance(rebalance_result, dict) or not rebalance_result.get('success'):
            error = (
                rebalance_result.get('error')
                if isinstance(rebalance_result, dict)
                else f"rebalance() 返回了 {type(rebalance_result).__name__}"
            ) or '调仓失败但未给出原因'
            # 保留 rebalance 给出的**具体**失败原因（如 factor_empty），
            # 拿不到可识别原因时才退回笼统的 rebalance_failed
            reported = (rebalance_result or {}).get('reason') if isinstance(rebalance_result, dict) else None
            reason = reported if reported in FAILED_REASONS else REASON_REBALANCE_FAILED
            logger.error(f"调仓未成功，如实上报（reason={reason}）: {error}")
            self._report_failure(reason, error, context={'date': today})
            detail['rebalance'] = rebalance_result if isinstance(rebalance_result, dict) else None
            return RunOutcome.failed(
                reason,
                error,
                action=ACTION_REBALANCE,
                detail=detail,
            ).to_dict()

        detail['rebalance'] = {
            'position_count': rebalance_result.get('position_count'),
            'total_value': rebalance_result.get('total_value'),
        }
        detail['notify_ok'] = rebalance_result.get('notify_ok')
        detail['notify_error'] = rebalance_result.get('notify_error')
        return RunOutcome.done(ACTION_REBALANCE, detail=detail).to_dict()

    def _report_failure(self, reason, error, context=None):
        """把失败交给统一的可见性出口（不抛异常，绝不影响业务链路）。"""
        try:
            report_failure(
                'strategy.daily_check',
                reason,
                error,
                severity=SEVERITY_HIGH,
                context={'account': getattr(self, 'account_name', None), **(context or {})},
            )
        except Exception as exc:  # noqa: BLE001 - 可见性失败不许打挂业务
            logger.error(f"失败外发通道异常（已吞）: {exc}")

    def _send_rebalance_notification(self, current_date, top_stocks, weights, latest_factors, total_value):
        """发送调仓通知"""
        try:
            # 准备Top 8股票信息
            top_stocks_info = []
            for symbol in top_stocks[:8]:
                pred_return = latest_factors[latest_factors['symbol'] == symbol]['predicted_return'].iloc[0]
                weight = weights.get(symbol, 0)

                # 获取当前价格
                try:
                    df = self.kline_repo.get_stock_kline(
                        symbol=symbol,
                        start_date=current_date,
                        end_date=current_date
                    )
                    price = float(df.iloc[-1]['close']) if not df.empty else 0
                except Exception:
                    price = 0

                # 判断是否买入/保留
                if symbol in self.portfolio:
                    note = f"(¥{price:.2f}，保留持仓)"
                else:
                    # 计算目标资金
                    target_value = total_value * weight * 0.7  # 假设仓位70%
                    can_buy = target_value >= price * 100 if price > 0 else False
                    if can_buy:
                        note = f"(¥{price:.2f}，买入)"
                    else:
                        note = f"(¥{price:.2f}，价格太高买不起)"

                top_stocks_info.append((symbol, pred_return, weight, note))

            # 收集买入/卖出交易（从最近的交易记录中获取）
            buy_trades = []
            sell_trades = []

            # 这里简化处理，实际应该从本次调仓的交易记录中提取
            for symbol, pos in self.portfolio.items():
                if symbol in top_stocks[:8]:
                    # 新买入或保留的
                    buy_trades.append((symbol, pos['shares'], pos['avg_price']))

            notification_data = {
                'date': current_date,
                'total_value': total_value,
                'cash': self.cash,
                'cumulative_return': (total_value / self.config['initial_capital'] - 1),
                'positions': len(self.portfolio),
                'top_stocks': top_stocks_info,
                'buy_trades': buy_trades,
                'sell_trades': sell_trades
            }

            if not self.notification_facade:
                # t2：facade 未装配必须可见（此前是静默跳过，只留 debug 级）
                logger.warning("调仓通知未发出：notification_facade 未装配")
                self._last_notify_error = 'notification_facade 未装配'
                return False

            # 使用新的 DDD 通知系统
            # 注意：旧版有 send_rebalance_notification，新版需要使用通用方法
            result = self.notification_facade.send_card(
                title=f"V13策略调仓通知 - {current_date}",
                content=self._format_rebalance_content(notification_data),
                urgency='normal'
            )
            if result:
                logger.info("调仓通知已发送")
                return True
            logger.error("调仓通知发送失败")
            self._last_notify_error = 'send_card 返回 False'
            return False

        except Exception as e:
            logger.error(f"发送调仓通知失败: {e}")
            self._last_notify_error = str(e)
            return False

    def _format_rebalance_content(self, data: dict) -> str:
        """格式化调仓通知内容"""
        content = f"""**🗓 调仓日期**: {data['date']}

**💰 账户状态**:
• 总资产: ¥{data['total_value']:,.2f}
• 现金余额: ¥{data['cash']:,.2f}
• 累计收益: {data['cumulative_return']*100:+.2f}% (¥{(data['total_value'] - self.config['initial_capital']):,.2f})
• 持仓数量: {data['positions']}只

**🎯 本次预测Top 8**:"""

        for i, (symbol, pred_return, weight, note) in enumerate(data['top_stocks'][:8], 1):
            status = "✅" if "买入" in note or "保留" in note else "❌"
            content += f"\n{i}. {symbol} - 预测{pred_return*100:+.2f}% {status} {note}"

        if data['buy_trades'] or data['sell_trades']:
            content += "\n\n**📈 实际操作**:"

        if data['buy_trades']:
            content += "\n**买入**:"
            for symbol, shares, price in data['buy_trades']:
                content += f"\n• {symbol}: {shares}股 @ ¥{price:.2f}"

        if data['sell_trades']:
            content += "\n**卖出**:"
            for symbol, shares, price in data['sell_trades']:
                content += f"\n• {symbol}: {shares}股 @ ¥{price:.2f}"

        return content

    def rebalance(self, current_date):
        """执行调仓"""
        logger.info("\n" + "="*60)
        logger.info(f"开始调仓流程 (账户: {self.account_name})")
        logger.info("="*60)

        try:
            # ✅ 调仓前数据一致性检查
            self._validate_data_consistency()

            # 1. 获取股票池
            stocks = self._get_stock_pool(limit=200)
            logger.info(f"股票池: {len(stocks)}只")

            # 2. 获取最新因子
            logger.info("计算最新因子...")
            latest_factors = self.factor_calc.get_latest_factors(stocks)

            if latest_factors.empty:
                logger.error("因子计算失败，取消调仓")
                # t2：取消调仓是**失败**，必须外发（此前只有一行日志）
                self._report_failure(
                    REASON_FACTOR_EMPTY,
                    '因子计算失败（get_latest_factors 返回空表）',
                    context={'date': current_date, 'stock_pool': len(stocks)},
                )
                return {
                    'success': False,
                    'error': '因子计算失败',
                    'reason': REASON_FACTOR_EMPTY,
                    'account_name': self.account_name
                }

            # 3. 模型预测
            logger.info("模型预测...")
            available_factors = [f for f in self.valid_factors if f in latest_factors.columns]

            if len(available_factors) < len(self.valid_factors) * 0.8:
                logger.warning(f"可用因子不足: {len(available_factors)}/{len(self.valid_factors)}")

            X_pred = latest_factors[available_factors].fillna(0)
            predictions = self.model.predict(X_pred)
            latest_factors['predicted_return'] = predictions

            # 4. 使用风险控制器选股
            top_stocks, weights = self.risk_controller.select_stocks(
                latest_factors[['symbol', 'predicted_return']],
                current_holdings=list(self.portfolio.keys())
            )
            logger.info(f"\n风控选股结果 (Top {len(top_stocks)}):")
            for symbol in top_stocks:
                pred = latest_factors[latest_factors['symbol'] == symbol]['predicted_return'].iloc[0]
                weight = weights[symbol]
                logger.info(f"  {symbol}: 预测收益={pred:.4f}, 权重={weight:.2%}")

            # 5. 计算当前状态
            total_value = self._calculate_total_value(current_date)
            current_return = (total_value / self.config['initial_capital'] - 1)

            # 更新峰值
            if total_value > self.peak_value:
                self.peak_value = total_value

            drawdown = (total_value / self.peak_value - 1)

            logger.info(f"\n当前状态:")
            logger.info(f"  总资产: ¥{total_value:,.2f}")
            logger.info(f"  累计收益: {current_return:.2%}")
            logger.info(f"  峰值回撤: {drawdown:.2%}")

            # 6. 使用风险控制器计算目标仓位
            position_scale = self.risk_controller.calculate_position_scale(
                current_value=total_value,
                peak_value=self.peak_value
            )
            logger.info(f"  目标仓位: {position_scale:.0%}")

            # 7. 执行交易（使用风控权重）
            self._execute_trades_with_risk_control(top_stocks, weights, position_scale, current_date)

            # 8. 更新状态
            self.last_rebalance_date = current_date
            self._save_account_to_db()

            # 9. 生成报告
            # self.generate_daily_report(current_date)  # 暂时注释，ORM Repository缺少get_latest_report

            # 10. 发送飞书通知（2026-09-11 w-23c70356）
            # 原写法 `if self.feishu_notifier:` 的 self.feishu_notifier 全仓从未被赋值
            # （本类实际用的是 self.notification_facade，见 __init__ 与 _send_rebalance_notification），
            # 该分支一旦进入即 AttributeError —— 残留死代码，直接删除；
            # _send_rebalance_notification 内部已用 notification_facade 自守卫。
            # t2：通知是**副作用**——它失败不得把一次成功的调仓判成失败（只留痕）。
            self._last_notify_error = None
            notify_ok = self._send_rebalance_notification(
                current_date,
                top_stocks,
                weights,
                latest_factors,
                total_value
            )

            logger.info("\n调仓完成\n")

            # 返回调仓结果
            return {
                'success': True,
                'account_name': self.account_name,
                'date': current_date,
                'total_value': self._sanitize_float(float(total_value)),
                'positions': [{
                    'symbol': symbol,
                    'weight': self._sanitize_float(float(weights[symbol]))
                } for symbol in top_stocks],
                'position_count': len(top_stocks),
                'notify_ok': notify_ok,
                'notify_error': getattr(self, '_last_notify_error', None),
            }

        except Exception as e:
            logger.error(f"调仓失败: {e}", exc_info=True)
            # t2：抛错必须外发（此前只有日志 → 上层还记 success）
            self._report_failure(
                REASON_REBALANCE_FAILED,
                e,
                context={'date': current_date, 'phase': 'rebalance'},
            )
            return {
                'success': False,
                'error': str(e),
                'account_name': self.account_name
            }

    def _calculate_total_value(self, date):
        """计算总资产"""
        # 获取当前价格
        symbols = list(self.portfolio.keys())
        if not symbols:
            return self.cash

        prices = {}
        for symbol in symbols:
            try:
                df = self.kline_repo.get_stock_kline(
                    symbol=symbol,
                    start_date=(datetime.now() - timedelta(days=7)).strftime('%Y-%m-%d'),
                    end_date=date
                )
                if not df.empty:
                    prices[symbol] = float(df.iloc[-1]['close'])
            except:
                prices[symbol] = self.portfolio[symbol]['avg_price']

        # 计算持仓市值
        portfolio_value = sum(
            self.portfolio[symbol]['shares'] * prices.get(symbol, self.portfolio[symbol]['avg_price'])
            for symbol in self.portfolio
        )

        return self.cash + portfolio_value

    def _execute_trades_with_risk_control(self, target_symbols, weights, position_scale, date):
        """执行交易（使用风险控制权重）"""
        target_symbols_set = set(target_symbols)

        logger.info(f"\n{'='*60}")
        logger.info(f"开始执行交易 (账户: {self.account_name})")
        logger.info(f"{'='*60}")
        logger.info(f"目标持仓: {len(target_symbols)}只 - {target_symbols}")
        logger.info(f"当前持仓: {len(self.portfolio)}只 - {list(self.portfolio.keys())}")
        logger.info(f"当前现金: ¥{self.cash:,.2f}")
        logger.info(f"目标仓位比例: {position_scale:.0%}")

        # 获取当前价格
        prices = self._get_current_prices(
            list(target_symbols_set | set(self.portfolio.keys())),
            date
        )
        logger.info(f"获取到{len(prices)}只股票价格")

        # 卖出不在目标中的股票
        for symbol in list(self.portfolio.keys()):
            if symbol not in target_symbols_set:
                shares = self.portfolio[symbol]['shares']

                # ✅ 防止重复卖出：检查持仓数量
                if shares <= 0:
                    logger.warning(f"跳过 {symbol}: 持仓数量={shares}，无需卖出")
                    del self.portfolio[symbol]
                    continue

                price = prices.get(symbol, self.portfolio[symbol]['avg_price'])

                # FR-10（t-900179）：清仓卖出前过硬校验——被拦截则保留该持仓、
                # 继续处理别的标的（不因一只账本矛盾的标的掀翻整次调仓）。
                if not self._assert_sellable(symbol, shares, path='rebalance_exit', date=date):
                    continue

                # 模拟交易
                trade = self.broker.sell(symbol, shares, price)
                self.cash += trade['total_revenue']

                # 保存交易记录到数据库
                self.repo.add_trade(
                    account_name=self.account_name,
                    symbol=symbol,
                    action='SELL',
                    shares=shares,
                    price=price,
                    filled_price=trade['filled_price'],
                    amount=trade['amount'],
                    commission=trade['commission'],
                    stamp_duty=trade.get('stamp_duty', 0),
                    total_revenue=trade['total_revenue'],
                    trade_date=date
                )

                # 删除持仓
                del self.portfolio[symbol]
                self.repo.delete_position(self.account_name, symbol)

                logger.info(f"卖出 {symbol}: {shares}股 @ ¥{price:.2f}")

        # 计算总资产
        total_value = self.cash + sum(
            self.portfolio[s]['shares'] * prices.get(s, self.portfolio[s]['avg_price'])
            for s in self.portfolio
        )

        # ✅ 关键检查：买入前验证现金是否充足
        if self.cash <= 0:
            logger.error(f"❌ 现金不足（¥{self.cash:,.2f}），取消所有买入操作")
            logger.error(f"   可能原因：卖出收入不足以支付新的买入")
            return

        available_cash = self.cash
        logger.info(f"\n可用现金: ¥{available_cash:,.2f}")

        # 买入目标股票（使用风控权重）
        for symbol in target_symbols:
            weight = weights[symbol]
            target_value = total_value * weight * position_scale
            price = prices.get(symbol, 0)

            if price <= 0:
                logger.warning(f"跳过 {symbol}: 价格无效")
                continue

            target_shares = int(target_value / price / 100) * 100  # 100股整数倍

            if target_shares == 0:
                continue

            # 如果已持有，调整仓位
            current_shares = self.portfolio.get(symbol, {}).get('shares', 0)
            delta_shares = target_shares - current_shares

            if delta_shares > 0:
                # 买入
                cost = delta_shares * price * (1 + self.config['trading']['commission_rate'])

                # ✅ 严格检查：本次买入是否超出可用现金
                if cost > available_cash:
                    logger.warning(f"跳过 {symbol}: 需要¥{cost:,.2f}，剩余现金¥{available_cash:,.2f}")
                    continue

                if cost <= self.cash:
                    trade = self.broker.buy(symbol, delta_shares, price)
                    self.cash -= trade['total_cost']
                    available_cash -= trade['total_cost']  # ✅ 同步扣除可用现金

                    # 保存交易记录到数据库
                    self.repo.add_trade(
                    account_name=self.account_name,
                        symbol=symbol,
                        action='BUY',
                        shares=delta_shares,
                        price=price,
                        filled_price=trade['filled_price'],
                        amount=trade['amount'],
                        commission=trade['commission'],
                        stamp_duty=0,
                        total_revenue=-trade['total_cost'],
                        trade_date=date
                    )

                    # 更新持仓
                    if symbol in self.portfolio:
                        old_shares = self.portfolio[symbol]['shares']
                        old_avg = self.portfolio[symbol]['avg_price']
                        new_shares = old_shares + delta_shares
                        new_avg = (old_shares * old_avg + delta_shares * trade['filled_price']) / new_shares
                        self.portfolio[symbol] = {'shares': new_shares, 'avg_price': new_avg}
                    else:
                        self.portfolio[symbol] = {'shares': delta_shares, 'avg_price': trade['filled_price']}

                    logger.info(f"买入 {symbol}: {delta_shares}股 @ ¥{price:.2f} (权重{weight:.2%}，花费¥{trade['total_cost']:,.2f}，剩余¥{available_cash:,.2f})")
                else:
                    logger.warning(f"资金不足，无法买入 {symbol}")


            elif delta_shares < 0:
                # 卖出部分
                sell_shares = -delta_shares
                # FR-10（t-900179）：减仓卖出前过硬校验（拦截则本标的这次不动）
                if not self._assert_sellable(
                        symbol, sell_shares, path='rebalance_trim', date=date):
                    continue
                trade = self.broker.sell(symbol, sell_shares, price)
                self.cash += trade['total_revenue']

                # 保存交易记录
                self.repo.add_trade(
                    account_name=self.account_name,
                    symbol=symbol,
                    action='SELL',
                    shares=sell_shares,
                    price=price,
                    filled_price=trade['filled_price'],
                    amount=trade['amount'],
                    commission=trade['commission'],
                    stamp_duty=trade.get('stamp_duty', 0),
                    total_revenue=trade['total_revenue'],
                    trade_date=date
                )

                # 更新持仓
                self.portfolio[symbol]['shares'] = current_shares - sell_shares
                if self.portfolio[symbol]['shares'] == 0:
                    del self.portfolio[symbol]
                    self.repo.delete_position(self.account_name, symbol)

                logger.info(f"减仓 {symbol}: {sell_shares}股 @ ¥{price:.2f}")

    def _get_current_prices(self, symbols, date):
        """
        获取当前价格（多数据源策略）

        优先级：
        1. 实时行情（盘中有效）- RealtimeQuoteService（多源自动fallback）
        2. 数据库K线（盘后有效）
        3. 持仓成本价（兜底）
        """
        from application.services.realtime_quote_service import RealtimeQuoteService

        prices = {}

        # 数据源1: 实时行情（通过统一服务，自动多源fallback）
        quote_service = RealtimeQuoteService()
        for symbol in symbols:
            try:
                quote = quote_service.get_realtime_quote(symbol)
                if quote and quote.price > 0:
                    prices[symbol] = quote.price
                    logger.info(f"{symbol} 实时价格: {quote.price:.2f} (来源: {quote.source})")
            except Exception as e:
                logger.debug(f"{symbol} 实时行情获取失败: {e}")

        # 数据源2: 数据库K线（补齐缺失的）
        missing = [s for s in symbols if s not in prices]
        if missing:
            for symbol in missing:
                try:
                    latest = self.kline_repo.get_latest_daily_kline(symbol)
                    if latest is not None and not latest.is_empty():
                        price = float(latest['close'][0])
                        if price > 0:
                            prices[symbol] = price
                            logger.info(f"{symbol} 数据库价格: {price:.2f}")
                except Exception as e:
                    logger.debug(f"{symbol} 数据库K线获取失败: {e}")

        # 数据源3: 持仓成本价（最终兜底）
        for symbol in symbols:
            if symbol not in prices or prices[symbol] <= 0:
                if symbol in self.portfolio:
                    prices[symbol] = self.portfolio[symbol]['avg_price']
                    logger.warning(f"{symbol} 无法获取市场价格，使用成本价 {prices[symbol]:.2f}")
                else:
                    prices[symbol] = 0

        return prices

    def _assert_sellable(self, symbol, shares, *, path, date=None) -> bool:
        """V13 卖出前的超卖硬校验（REQ-261004154902-a7cd · t-900179 / FR-10）。

        判定的**唯一实现**在应用层
        ``application.services.account_trading_service.check_sellable``——
        本文件**不再写第二个净额口径**（两套口径正是历史虚增 ≈¥49,425 的成因）。
        外发也在那里完成（`report_failure`，source=``account_trading.oversell_check``，
        reason=``oversell_blocked``），此处只补一条带**路径**的日志并决定本笔怎么办，
        避免同一笔拦截发两条通知（防刷屏）。

        Returns:
            True = 放行；False = 已拦截（外发 + 日志已发生），调用方**跳过这笔卖出**。
        """
        try:
            from application.services.account_trading_service import (
                TradingError, check_sellable,
            )
            check_sellable(
                self.repo, self.account_name, symbol, shares,
                context={'path': path, 'date': str(date) if date else None,
                         'phase': 'simulation_trader'},
            )
            return True
        except TradingError as exc:
            logger.error(
                f"⛔ 超卖拦截（{path}）：跳过卖出 {symbol} {shares}股 —— {exc}"
            )
            return False

    def _execute_stop_loss(self, symbols, prices, date):
        """执行止损"""
        for symbol in symbols:
            if symbol not in self.portfolio:
                continue

            shares = self.portfolio[symbol]['shares']
            price = prices[symbol]

            # FR-10（t-900179）：止损卖出前也要过硬校验——被拦截就跳过该标的，
            # 绝不用"凭空多出来的持仓"再换一次现金（虚增现金正是这么来的）。
            if not self._assert_sellable(symbol, shares, path='stop_loss', date=date):
                continue

            # 模拟交易
            trade = self.broker.sell(symbol, shares, price)
            self.cash += trade['total_revenue']

            # 保存交易记录
            self.repo.add_trade(
                    account_name=self.account_name,
                symbol=symbol,
                action='SELL',
                shares=shares,
                price=price,
                filled_price=trade['filled_price'],
                amount=trade['amount'],
                commission=trade['commission'],
                stamp_duty=trade.get('stamp_duty', 0),
                total_revenue=trade['total_revenue'],
                trade_date=date
            )

            # 删除持仓
            del self.portfolio[symbol]
            self.repo.delete_position(self.account_name, symbol)

            logger.warning(f"止损卖出 {symbol}: {shares}股 @ ¥{price:.2f}")

    def _calculate_position_scale(self, current_return, drawdown):
        """计算仓位比例（旧方法，保留兼容性）"""
        # 检查止盈
        for level in self.config['strategy']['take_profit_levels']:
            if current_return >= level['threshold']:
                return level['position']

        # 检查止损
        for stop in self.config['strategy']['drawdown_stops']:
            if drawdown <= stop['threshold']:
                return stop['position']

        return 1.0

    def _execute_trades(self, top5, position_scale, date):
        """执行交易（旧方法，保留兼容性）"""
        target_symbols = set(top5['symbol'].tolist())
        target_weight = self.config['strategy']['position_weight'] * position_scale

        # 获取当前价格（使用实时数据接口）
        prices = {}
        for symbol in target_symbols | set(self.portfolio.keys()):
            try:
                latest = self.kline_repo.get_latest_daily_kline(symbol)
                if latest is not None and not latest.is_empty():
                    prices[symbol] = float(latest['close'][0])
                else:
                    prices[symbol] = self.portfolio.get(symbol, {}).get('avg_price', 0)
            except:
                if symbol in self.portfolio:
                    prices[symbol] = self.portfolio[symbol]['avg_price']

        # 卖出不在目标中的股票
        for symbol in list(self.portfolio.keys()):
            if symbol not in target_symbols:
                shares = self.portfolio[symbol]['shares']
                price = prices.get(symbol, self.portfolio[symbol]['avg_price'])

                # 模拟交易
                trade = self.broker.sell(symbol, shares, price)
                self.cash += trade['total_revenue']

                # 保存交易记录到数据库
                self.repo.add_trade(
                    account_name=self.account_name,
                    symbol=symbol,
                    action='SELL',
                    shares=shares,
                    price=price,
                    filled_price=trade['filled_price'],
                    amount=trade['amount'],
                    commission=trade['commission'],
                    stamp_duty=trade.get('stamp_duty', 0),
                    total_revenue=trade['total_revenue'],
                    trade_date=date
                )

                # 删除持仓
                del self.portfolio[symbol]
                self.repo.delete_position(self.account_name, symbol)

        # 计算总资产
        total_value = self.cash + sum(
            self.portfolio[s]['shares'] * prices.get(s, self.portfolio[s]['avg_price'])
            for s in self.portfolio
        )

        # 买入目标股票
        for symbol in target_symbols:
            target_value = total_value * target_weight
            price = prices.get(symbol, 0)

            if price <= 0:
                continue

            target_shares = int(target_value / price / 100) * 100  # 100股整数倍

            if target_shares == 0:
                continue

            # 如果已持有，调整仓位
            current_shares = self.portfolio.get(symbol, {}).get('shares', 0)
            delta_shares = target_shares - current_shares

            if delta_shares > 0:
                # 买入
                cost = delta_shares * price * (1 + self.config['trading']['commission_rate'])
                if cost <= self.cash:
                    trade = self.broker.buy(symbol, delta_shares, price)
                    self.cash -= trade['total_cost']

                    # 保存交易记录到数据库
                    self.repo.add_trade(
                    account_name=self.account_name,
                        symbol=symbol,
                        action='BUY',
                        shares=delta_shares,
                        price=price,
                        filled_price=trade['filled_price'],
                        amount=trade['amount'],
                        commission=trade['commission'],
                        total_cost=trade['total_cost'],
                        trade_date=date
                    )

                    if symbol in self.portfolio:
                        # 更新持仓成本
                        total_shares = self.portfolio[symbol]['shares'] + delta_shares
                        total_cost = (self.portfolio[symbol]['shares'] * self.portfolio[symbol]['avg_price'] +
                                     trade['total_cost'])
                        self.portfolio[symbol] = {
                            'shares': total_shares,
                            'avg_price': total_cost / total_shares
                        }
                    else:
                        self.portfolio[symbol] = {
                            'shares': delta_shares,
                            'avg_price': trade['total_cost'] / delta_shares
                        }

                    # 更新数据库持仓
                    self.repo.upsert_position(
                        account_name=self.account_name,
                        symbol=symbol,
                        shares=self.portfolio[symbol]['shares'],
                        avg_price=self.portfolio[symbol]['avg_price'],
                        current_price=price
                    )

            elif delta_shares < 0:
                # 卖出部分
                trade = self.broker.sell(symbol, abs(delta_shares), price)
                self.cash += trade['total_revenue']

                # 保存交易记录
                self.repo.add_trade(
                    account_name=self.account_name,
                    symbol=symbol,
                    action='SELL',
                    shares=abs(delta_shares),
                    price=price,
                    filled_price=trade['filled_price'],
                    amount=trade['amount'],
                    commission=trade['commission'],
                    stamp_duty=trade.get('stamp_duty', 0),
                    total_revenue=trade['total_revenue'],
                    trade_date=date
                )

                self.portfolio[symbol]['shares'] -= abs(delta_shares)

                # 更新数据库持仓
                self.repo.upsert_position(
                    symbol=symbol,
                    shares=self.portfolio[symbol]['shares'],
                    avg_price=self.portfolio[symbol]['avg_price'],
                    current_price=price
                )

        logger.info(f"\n交易完成:")
        logger.info(f"  现金余额: ¥{self.cash:,.2f}")
        logger.info(f"  持仓数量: {len(self.portfolio)}只")

    def generate_daily_report(self, date):
        """生成每日报告（保存到数据库）"""
        total_value = self._calculate_total_value_from_portfolio()
        initial_capital = self.config['initial_capital']

        # 获取昨日报告计算日收益
        previous_report = self.repo.get_latest_report()
        if previous_report:
            previous_value = float(previous_report['total_value'])
            daily_return = (total_value / previous_value - 1) if previous_value > 0 else 0
        else:
            daily_return = (total_value / initial_capital - 1)

        cumulative_return = (total_value / initial_capital - 1)
        drawdown = (total_value / self.peak_value - 1) if self.peak_value > 0 else 0

        # 计算持仓市值
        position_value = total_value - self.cash

        # 获取今日交易次数
        trade_count = self.repo.get_trade_count(account_name=self.account_name, start_date=date, end_date=date)

        # 保存到数据库
        self.repo.save_daily_report(
            report_date=date,
            cash=self.cash,
            position_value=position_value,
            total_value=total_value,
            daily_return=daily_return,
            cumulative_return=cumulative_return,
            peak_value=self.peak_value,
            drawdown=drawdown,
            position_count=len(self.portfolio),
            trade_count=trade_count
        )

        # 同时保存JSON文件（兼容）
        report_dir = Path(self.config['storage']['daily_report_file']).parent
        report_dir.mkdir(parents=True, exist_ok=True)

        report = {
            'date': date,
            'cash': self.cash,
            'position_value': position_value,
            'total_value': total_value,
            'daily_return': daily_return,
            'cumulative_return': cumulative_return,
            'drawdown': drawdown,
            'peak_value': self.peak_value,
            'position_count': len(self.portfolio),
            'trade_count': trade_count
        }

        report_file = report_dir / f"daily_{date}.json"
        with open(report_file, 'w', encoding='utf-8') as f:
            json.dump(report, f, ensure_ascii=False, indent=2)

        logger.info(f"每日报告已保存到数据库和文件")


def main():
    """主函数"""
    print("V13策略模拟交易系统（数据库版）")
    print("="*60)

    # 初始化交易器
    trader = SimulationTrader()

    print("\n请选择操作:")
    print("1. 训练模型")
    print("2. 加载模型")
    print("3. 执行每日检查")
    print("4. 查看持仓（数据库）")
    print("5. 查看交易记录（数据库）")
    print("6. 查看每日报告（数据库）")
    print("7. 退出")

    choice = input("\n请输入选项 (1-7): ")

    if choice == '1':
        print("\n开始训练模型...")
        trader.train_model()
        print("模型训练完成!")

    elif choice == '2':
        print("\n加载模型...")
        trader.load_model()
        print("模型加载完成!")

    elif choice == '3':
        print("\n执行每日检查...")
        trader.run_daily_check()

    elif choice == '4':
        print("\n当前持仓（从数据库）:")
        account = trader.repo.get_account(trader.account_name)
        print(f"现金: ¥{float(account.cash_available or 0) + float(account.cash_frozen or 0):,.2f}")
        print(f"总资产: ¥{float(account.total_value or 0):,.2f}")
        print(f"累计收益: {float(account.cumulative_return or 0):.2%}")
        print(f"最大回撤: {float(account.max_drawdown or 0):.2%}")

        positions = trader.repo.get_all_positions(trader.account_name)
        print(f"\n持仓数量: {len(positions)}只")
        for pos in positions:
            print(f"  {pos.symbol}: {pos.shares_total}股 @ ¥{float(pos.avg_cost):.2f}")

    elif choice == '5':
        print("\n交易记录（从数据库）:")
        trades = trader.repo.get_trades(limit=20)
        if trades:
            for trade in trades:
                print(f"{trade['trade_time']} {trade['action']} {trade['symbol']} "
                      f"{trade['shares']}股 @ ¥{trade['filled_price']:.2f}")
            print(f"\n总手续费: ¥{trader.repo.get_total_commission():.2f}")
        else:
            print("暂无交易记录")

    elif choice == '6':
        print("\n每日报告（从数据库）:")
        reports = trader.repo.get_daily_reports(limit=10)
        if reports:
            for report in reports:
                print(f"{report['report_date']}: 总资产¥{report['total_value']:,.2f}, "
                      f"收益{report['cumulative_return']:.2%}, "
                      f"回撤{report['drawdown']:.2%}")
        else:
            print("暂无报告")

    elif choice == '7':
        print("\n退出系统")

    else:
        print("\n无效选项")


if __name__ == '__main__':
    main()
