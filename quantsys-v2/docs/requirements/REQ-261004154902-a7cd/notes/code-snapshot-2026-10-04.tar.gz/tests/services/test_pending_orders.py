"""条件委托（pending orders）服务层测试

盘前（非交易时段）可下 execute_at='market_open' 的挂单，
开盘后由 orchestrator 调 execute_pending_orders 自动撮合。

全部 mock repo/calendar，不依赖数据库；时间通过 now_fn 注入。
"""
from datetime import datetime
from types import SimpleNamespace
from unittest.mock import Mock

import pytest

from application.services.account_trading_service import (
    AccountTradingService, TradingError,
)

REASON = '测试买入：技术面突破且放量，符合策略入场条件'


# ---------- fixtures ----------

@pytest.fixture()
def repo():
    return Mock()


@pytest.fixture()
def calendar():
    cal = Mock()
    cal.is_trading_day.return_value = True  # 默认交易日
    return cal


def _make_service(repo, calendar, now):
    return AccountTradingService(
        repo=repo, calendar=calendar, now_fn=lambda: now)


def _active_account(**overrides):
    defaults = dict(
        account_name='acc', status='active',
        cash_available=100000.0, cash_frozen=0.0,
        position_value=0.0, total_value=100000.0,
        peak_value=100000.0, initial_capital=100000.0,
        cumulative_return=0.0,
    )
    defaults.update(overrides)
    return SimpleNamespace(**defaults)


def _setup_trade_path(repo):
    """让 execute_trade 的完整护栏路径可走通（买入 100 股 @10）"""
    repo.get_account.return_value = _active_account()
    repo.get_account_for_update.return_value = repo.get_account.return_value
    repo.get_all_positions.return_value = []
    repo.get_trades_by_account.return_value = []
    repo.create_order.return_value = SimpleNamespace(id=1)
    repo.add_trade.return_value = 7


def _pending_order(**overrides):
    defaults = dict(
        id=1, account_name='acc', symbol='600519', action='buy',
        shares=100, amount=None, price_limit=None, reason=REASON,
        execute_at='market_open', status='pending',
        fail_reason=None, executed_trade_id=None,
        # 2026-10-02（REQ-261001145152-3982 审查）：补上 decision_price。
        # `account_trading_service` 执行挂单时读 `po.decision_price` 作为滑点基准
        # （该列正是本次补齐的 51 列之一：simulation_pending_orders.decision_price），
        # 而本假对象此前缺此属性 → 2 条用例报
        # AttributeError: 'types.SimpleNamespace' object has no attribute 'decision_price'。
        # 这里给一个值（而非 None），以便滑点分支真正被走到。
        decision_price=10.0,
    )
    defaults.update(overrides)
    return SimpleNamespace(**defaults)


# ---------- execute_trade + execute_at ----------

class TestPlacePendingOrder:
    """非交易时段 + execute_at='market_open' → 挂单"""

    def test_off_hours_with_execute_at_creates_pending(self, repo, calendar):
        svc = _make_service(repo, calendar, datetime(2026, 7, 28, 20, 0))
        repo.get_account.return_value = _active_account()
        repo.get_pending_orders.return_value = []  # 无既有挂单 → 查重放行
        repo.create_pending_order.return_value = SimpleNamespace(id=42)

        result = svc.execute_trade(
            'acc', 'buy', '600519', shares=100,
            reason=REASON, execute_at='market_open')

        assert result['status'] == 'pending'
        assert result['pending_order_id'] == 42
        assert '9:31' in result['message']
        repo.create_pending_order.assert_called_once()
        kwargs = repo.create_pending_order.call_args.kwargs
        assert kwargs['account_name'] == 'acc'
        assert kwargs['action'] == 'BUY'  # action 大写契约（08-13，落库前已规范化）
        assert kwargs['symbol'] == '600519'
        assert kwargs['shares'] == 100
        assert kwargs['execute_at'] == 'market_open'

    def test_off_hours_without_execute_at_still_422(self, repo, calendar):
        """现有行为不变：无 execute_at 时非交易时段仍拒绝"""
        svc = _make_service(repo, calendar, datetime(2026, 7, 28, 20, 0))
        with pytest.raises(TradingError) as exc:
            svc.execute_trade('acc', 'buy', '600519', shares=100, reason=REASON)
        assert exc.value.status_code == 422
        repo.create_pending_order.assert_not_called()

    def test_in_window_with_execute_at_executes_directly(self, repo, calendar):
        """交易时段内带 execute_at → 直接成交，不落挂单"""
        svc = _make_service(repo, calendar, datetime(2026, 7, 28, 10, 0))
        _setup_trade_path(repo)

        result = svc.execute_trade(
            'acc', 'buy', '600519', shares=100,
            reason=REASON, price=10.0, execute_at='market_open')

        assert result['order_status'] == 'filled'
        assert result['shares'] == 100
        repo.create_pending_order.assert_not_called()

    def test_pending_validates_reason(self, repo, calendar):
        svc = _make_service(repo, calendar, datetime(2026, 7, 28, 20, 0))
        with pytest.raises(TradingError) as exc:
            svc.execute_trade('acc', 'buy', '600519', shares=100,
                              reason='太短', execute_at='market_open')
        assert exc.value.status_code == 400
        repo.create_pending_order.assert_not_called()

    def test_pending_validates_action(self, repo, calendar):
        svc = _make_service(repo, calendar, datetime(2026, 7, 28, 20, 0))
        with pytest.raises(TradingError) as exc:
            svc.execute_trade('acc', 'hold', '600519', shares=100,
                              reason=REASON, execute_at='market_open')
        assert exc.value.status_code == 400
        repo.create_pending_order.assert_not_called()

    def test_pending_validates_account_exists(self, repo, calendar):
        svc = _make_service(repo, calendar, datetime(2026, 7, 28, 20, 0))
        repo.get_account.return_value = None
        with pytest.raises(TradingError) as exc:
            svc.execute_trade('ghost', 'buy', '600519', shares=100,
                              reason=REASON, execute_at='market_open')
        assert exc.value.status_code == 404
        repo.create_pending_order.assert_not_called()

    def test_pending_validates_account_active(self, repo, calendar):
        svc = _make_service(repo, calendar, datetime(2026, 7, 28, 20, 0))
        repo.get_account.return_value = _active_account(status='archived')
        with pytest.raises(TradingError) as exc:
            svc.execute_trade('acc', 'buy', '600519', shares=100,
                              reason=REASON, execute_at='market_open')
        assert exc.value.status_code == 409
        repo.create_pending_order.assert_not_called()

    def test_invalid_execute_at_rejected(self, repo, calendar):
        svc = _make_service(repo, calendar, datetime(2026, 7, 28, 20, 0))
        with pytest.raises(TradingError) as exc:
            svc.execute_trade('acc', 'buy', '600519', shares=100,
                              reason=REASON, execute_at='next_week')
        assert exc.value.status_code == 400
        repo.create_pending_order.assert_not_called()


# ---------- 重复挂单拦截（2026-09-03） ----------

class TestDuplicatePendingOrderGuard:
    """同标的同方向已有 pending 单 → 409 拦截；allow_duplicate=True 放行

    背景：002241 凌晨限价单 + 盘前市价单撞单（两笔 SELL 300 股 pending），
    若双双撮合即意外清仓。拦截默认开启，agent 确认后显式放行。
    """

    def _setup(self, repo, existing_orders):
        repo.get_account.return_value = _active_account()
        repo.get_pending_orders.return_value = existing_orders
        repo.create_pending_order.return_value = SimpleNamespace(id=99)

    def test_duplicate_same_direction_blocked(self, repo, calendar):
        svc = _make_service(repo, calendar, datetime(2026, 7, 28, 20, 0))
        self._setup(repo, [_pending_order(id=18, symbol='002241', action='SELL',
                                          shares=300, price_limit=23.6)])

        with pytest.raises(TradingError) as exc:
            svc.execute_trade('acc', 'sell', '002241', shares=300,
                              reason=REASON, execute_at='market_open')

        assert exc.value.status_code == 409
        assert 'id=18' in str(exc.value)
        assert 'allow_duplicate' in str(exc.value)
        assert exc.value.details is not None
        assert len(exc.value.details['conflicts']) == 1
        repo.create_pending_order.assert_not_called()

    def test_allow_duplicate_true_passes(self, repo, calendar):
        svc = _make_service(repo, calendar, datetime(2026, 7, 28, 20, 0))
        self._setup(repo, [_pending_order(id=18, symbol='002241', action='SELL',
                                          shares=300)])

        result = svc.execute_trade('acc', 'sell', '002241', shares=300,
                                   reason=REASON, execute_at='market_open',
                                   allow_duplicate=True)

        assert result['status'] == 'pending'
        assert result['pending_order_id'] == 99
        repo.create_pending_order.assert_called_once()

    def test_opposite_direction_not_blocked(self, repo, calendar):
        """同标的反方向（已有 SELL，挂 BUY）不拦截"""
        svc = _make_service(repo, calendar, datetime(2026, 7, 28, 20, 0))
        self._setup(repo, [_pending_order(id=18, symbol='002241', action='SELL',
                                          shares=300)])

        result = svc.execute_trade('acc', 'buy', '002241', shares=100,
                                   reason=REASON, execute_at='market_open')

        assert result['status'] == 'pending'
        repo.create_pending_order.assert_called_once()

    def test_different_symbol_not_blocked(self, repo, calendar):
        """同方向不同标的不拦截"""
        svc = _make_service(repo, calendar, datetime(2026, 7, 28, 20, 0))
        self._setup(repo, [_pending_order(id=18, symbol='002241', action='SELL',
                                          shares=300)])

        result = svc.execute_trade('acc', 'sell', '600519', shares=100,
                                   reason=REASON, execute_at='market_open')

        assert result['status'] == 'pending'
        repo.create_pending_order.assert_called_once()

    def test_lowercase_existing_action_also_blocked(self, repo, calendar):
        """既有单 action 为小写落库时也能命中查重（大小写归一）"""
        svc = _make_service(repo, calendar, datetime(2026, 7, 28, 20, 0))
        self._setup(repo, [_pending_order(id=18, symbol='002241', action='sell',
                                          shares=300)])

        with pytest.raises(TradingError) as exc:
            svc.execute_trade('acc', 'SELL', '002241', shares=100,
                              reason=REASON, execute_at='market_open')

        assert exc.value.status_code == 409
        repo.create_pending_order.assert_not_called()


# ---------- execute_pending_orders ----------

class TestExecutePendingOrders:
    def test_success_marks_executed(self, repo, calendar):
        svc = _make_service(repo, calendar, datetime(2026, 7, 28, 9, 31))
        _setup_trade_path(repo)
        svc._get_price = lambda symbol: 10.0  # 撮合时取价，避免真实行情
        repo.get_pending_orders.return_value = [_pending_order(id=1)]

        result = svc.execute_pending_orders()

        assert result['executed'] == 1
        assert result['failed'] == 0
        assert result['details'][0]['status'] == 'executed'
        assert result['details'][0]['trade_id'] == 7
        # 2026-10-02（REQ-261001145152-3982 审查）：生产调用后来增加了滑点留痕
        # （fill_price / slippage_bps，M5 闭环），而本断言写于此前 → 补上这两个 kwarg。
        # 数值自洽：假订单 decision_price=10.0，成交价也是 10.0 → 滑点 0 bps。
        repo.update_pending_order_status.assert_called_once_with(
            1, 'executed', executed_trade_id=7, fill_price=10.0, slippage_bps=0.0)

    def test_guardrail_rejection_marks_failed(self, repo, calendar):
        """护栏拒绝（如账户不存在）→ failed + fail_reason"""
        svc = _make_service(repo, calendar, datetime(2026, 7, 28, 9, 31))
        repo.get_account.return_value = None  # 账户不存在 → 404
        repo.get_pending_orders.return_value = [_pending_order(id=2)]

        result = svc.execute_pending_orders()

        assert result['executed'] == 0
        assert result['failed'] == 1
        assert result['details'][0]['status'] == 'failed'
        assert '账户不存在' in result['details'][0]['fail_reason']
        repo.update_pending_order_status.assert_called_once_with(
            2, 'failed', fail_reason=result['details'][0]['fail_reason'])

    def test_idempotent_no_pending(self, repo, calendar):
        """无 pending 订单时是 no-op（每个 tick 幂等）"""
        svc = _make_service(repo, calendar, datetime(2026, 7, 28, 9, 32))
        repo.get_pending_orders.return_value = []

        result = svc.execute_pending_orders()

        # 2026-10-04（REQ-261004154902-a7cd t4）：返回体新增三个计数
        # （errored / expired / skipped_off_hours），既有三个键语义不变。
        assert result == {
            'executed': 0, 'failed': 0, 'errored': 0, 'expired': 0,
            'skipped_off_hours': 0, 'details': [],
        }
        repo.update_pending_order_status.assert_not_called()

    def test_mixed_outcomes(self, repo, calendar):
        svc = _make_service(repo, calendar, datetime(2026, 7, 28, 9, 31))
        _setup_trade_path(repo)
        svc._get_price = lambda symbol: 10.0  # 撮合时取价，避免真实行情
        orders = [_pending_order(id=1, account_name='acc'),
                  _pending_order(id=2, account_name='ghost')]
        repo.get_pending_orders.return_value = orders

        def get_account(name):
            return _active_account() if name == 'acc' else None
        repo.get_account.side_effect = get_account
        repo.get_account_for_update.side_effect = get_account

        result = svc.execute_pending_orders()

        assert result['executed'] == 1
        assert result['failed'] == 1
        assert repo.update_pending_order_status.call_count == 2


# ---------- cancel ----------

class TestCancelPendingOrder:
    def test_cancel_pending_success(self, repo, calendar):
        svc = _make_service(repo, calendar, datetime(2026, 7, 28, 20, 0))
        repo.get_pending_order.return_value = _pending_order(id=5)

        result = svc.cancel_pending_order('acc', 5)

        assert result['status'] == 'cancelled'
        assert result['pending_order_id'] == 5
        repo.update_pending_order_status.assert_called_once_with(5, 'cancelled')

    def test_cancel_executed_rejected(self, repo, calendar):
        svc = _make_service(repo, calendar, datetime(2026, 7, 28, 20, 0))
        repo.get_pending_order.return_value = _pending_order(id=5, status='executed')

        with pytest.raises(TradingError) as exc:
            svc.cancel_pending_order('acc', 5)
        assert exc.value.status_code == 409
        repo.update_pending_order_status.assert_not_called()

    def test_cancel_not_found(self, repo, calendar):
        svc = _make_service(repo, calendar, datetime(2026, 7, 28, 20, 0))
        repo.get_pending_order.return_value = None

        with pytest.raises(TradingError) as exc:
            svc.cancel_pending_order('acc', 999)
        assert exc.value.status_code == 404

    def test_cancel_other_account_rejected(self, repo, calendar):
        svc = _make_service(repo, calendar, datetime(2026, 7, 28, 20, 0))
        repo.get_pending_order.return_value = _pending_order(
            id=5, account_name='someone_else')

        with pytest.raises(TradingError) as exc:
            svc.cancel_pending_order('acc', 5)
        assert exc.value.status_code == 404
        repo.update_pending_order_status.assert_not_called()


# ---------- t4（FR-7）：撮合健壮性 ----------

class TestExecutePendingOrdersRobustness:
    """单笔异常不中断整批 / 非交易时段不误杀 / 超期作废并告警。

    2026-10-04（REQ-261004154902-a7cd t4）。三条都出自实证：
    · 两笔挂单自 2026-08-24 起 41 天 `updated_at == created_at`（loop 被异常掀翻）
    · 2026-08-21 16:41 两笔在盘后被拒成 failed 后永久丢弃（没有时段护栏）
    · 挂单没有超期概念 → 链路一断就无限期躺在 pending 里，无人知
    """

    @pytest.fixture(autouse=True)
    def _record_failures(self, monkeypatch):
        """打桩失败出口：新语义会主动外发，测试期真实外发会被 notify-guard 判失败。"""
        recorded = []
        monkeypatch.setattr(
            'application.services.account_trading_service.report_failure',
            lambda source, reason, error=None, severity='normal', context=None: recorded.append(
                {'source': source, 'reason': reason, 'error': error,
                 'severity': severity, 'context': context}
            ) or True,
        )
        return recorded

    def test_internal_error_does_not_stop_the_batch(self, repo, calendar, _record_failures):
        """一笔抛非护栏异常 → 该笔标 failed 并留痕，后面那笔**仍要被处理**。"""
        svc = _make_service(repo, calendar, datetime(2026, 7, 28, 9, 31))
        _setup_trade_path(repo)
        repo.get_pending_orders.return_value = [
            _pending_order(id=1, symbol='BOOM'),
            _pending_order(id=2, symbol='600519'),
        ]

        real_execute = svc.execute_trade

        def flaky_execute(**kwargs):
            if kwargs.get('symbol') == 'BOOM':
                raise RuntimeError('shape mismatch: expected 75 features, got 40')
            return real_execute(**kwargs)

        svc.execute_trade = flaky_execute
        svc._get_price = lambda symbol: 10.0

        result = svc.execute_pending_orders()

        assert result['errored'] == 1, result
        assert result['executed'] == 1, '第二笔必须仍被处理（批量不中断）'
        assert result['details'][0]['status'] == 'failed'
        assert 'internal_error' in result['details'][0]['fail_reason']
        repo.update_pending_order_status.assert_any_call(
            1, 'failed', fail_reason=result['details'][0]['fail_reason'])
        assert any(f['source'] == 'pending_orders.match' for f in _record_failures), _record_failures

    def test_off_hours_skips_without_failing_orders(self, repo, calendar):
        """盘后调用 → 全部跳过、状态保持 pending（绝不误杀）。"""
        svc = _make_service(repo, calendar, datetime(2026, 7, 28, 16, 41))
        repo.get_pending_orders.return_value = [_pending_order(id=5), _pending_order(id=6)]

        result = svc.execute_pending_orders()

        assert result['skipped_off_hours'] == 2
        assert result['failed'] == 0
        assert result['executed'] == 0
        assert result['expired'] == 0
        repo.update_pending_order_status.assert_not_called()

    def test_stale_pending_order_is_expired_and_alerted(self, repo, calendar, _record_failures):
        """错过至少一次开盘机会 → expired + 告警（不再无声搁浅）。"""
        svc = _make_service(repo, calendar, datetime(2026, 10, 6, 9, 31))
        _setup_trade_path(repo)
        repo.get_pending_orders.return_value = [
            _pending_order(id=7, created_at=datetime(2026, 8, 24, 9, 15)),
        ]
        svc._get_price = lambda symbol: 10.0

        result = svc.execute_pending_orders()

        assert result['expired'] == 1
        assert result['executed'] == 0
        repo.update_pending_order_status.assert_called_once()
        args, kwargs = repo.update_pending_order_status.call_args
        assert args[0] == 7 and args[1] == 'expired'
        assert 'expired' in kwargs['fail_reason']
        assert any(f['source'] == 'pending_orders.expired' for f in _record_failures), _record_failures

    def test_order_from_previous_session_is_not_expired(self, repo, calendar):
        """昨晚下的单在今天的开盘被撮合 → 正常成交，不许误判超期。"""
        svc = _make_service(repo, calendar, datetime(2026, 10, 6, 9, 31))
        _setup_trade_path(repo)
        repo.get_pending_orders.return_value = [
            _pending_order(id=8, created_at=datetime(2026, 10, 5, 16, 43)),
        ]
        svc._get_price = lambda symbol: 10.0

        result = svc.execute_pending_orders()

        assert result['executed'] == 1, result
        assert result['expired'] == 0

    def test_expiry_unknown_when_calendar_unavailable(self, repo, calendar, _record_failures):
        """交易日历取不到 → 判定不了就**不动它**，但必须留痕外发（不许假装没超期）。"""
        svc = _make_service(repo, calendar, datetime(2026, 10, 6, 9, 31))
        _setup_trade_path(repo)
        # 第一次调用（时段护栏）照常放行，第二次（超期判定里的日期遍历）失败
        calendar.is_trading_day.side_effect = [True, RuntimeError('calendar table missing')]
        repo.get_pending_orders.return_value = [
            _pending_order(id=9, created_at=datetime(2026, 8, 24, 9, 15)),
        ]
        svc._get_price = lambda symbol: 10.0

        result = svc.execute_pending_orders()

        assert result['expired'] == 0, '判定不了不许作废'
        assert any(f['source'] == 'pending_orders.expiry_check' for f in _record_failures), _record_failures

    def test_calendar_down_at_entry_skips_instead_of_crashing(self, repo, calendar, _record_failures):
        """入口就取不到日历 → 保守跳过并留痕（不抛、也不在未知开市状态下下单）。"""
        svc = _make_service(repo, calendar, datetime(2026, 10, 6, 9, 31))
        _setup_trade_path(repo)
        calendar.is_trading_day.side_effect = RuntimeError('calendar table missing')
        repo.get_pending_orders.return_value = [_pending_order(id=11)]

        result = svc.execute_pending_orders()

        assert result['executed'] == 0 and result['failed'] == 0
        assert result['details'][0]['status'] == 'skipped_calendar_unavailable'
        repo.update_pending_order_status.assert_not_called()
        assert any(f['source'] == 'pending_orders.window_check' for f in _record_failures), _record_failures

    def test_expiry_can_be_disabled(self, repo, calendar):
        """`expire_stale=False` 时只撮合、不做过期判定（留给运维/回放用）。"""
        svc = _make_service(repo, calendar, datetime(2026, 10, 6, 9, 31))
        _setup_trade_path(repo)
        repo.get_pending_orders.return_value = [
            _pending_order(id=10, created_at=datetime(2026, 8, 24, 9, 15)),
        ]
        svc._get_price = lambda symbol: 10.0

        result = svc.execute_pending_orders(expire_stale=False)

        assert result['expired'] == 0
        assert result['executed'] == 1
